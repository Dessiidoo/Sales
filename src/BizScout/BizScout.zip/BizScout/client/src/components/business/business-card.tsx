import { Business } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building, MapPin, Phone, Globe } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface BusinessCardProps {
  business: Business;
  onCreatePackage?: (business: Business) => void;
  onSendEmail?: (business: Business) => void;
  showActions?: boolean;
}

export default function BusinessCard({ 
  business, 
  onCreatePackage, 
  onSendEmail, 
  showActions = true 
}: BusinessCardProps) {
  
  const getBusinessIcon = (businessType: string) => {
    // Simple mapping - in production you'd want a more comprehensive mapping
    const iconMap: { [key: string]: string } = {
      'Hair Salons': 'fas fa-cut',
      'Landscaping': 'fas fa-leaf',
      'Food Trucks': 'fas fa-truck',
      'Cleaning Services': 'fas fa-broom',
      'Auto Repair': 'fas fa-wrench',
      'Pet Services': 'fas fa-paw',
    };
    
    return iconMap[businessType] || 'fas fa-building';
  };

  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg" data-testid={`business-card-${business.id}`}>
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 bg-gray-300 rounded-lg flex items-center justify-center">
          <Building className="h-6 w-6 text-gray-600" />
        </div>
        <div>
          <h4 className="font-medium text-gray-900" data-testid="business-name">
            {business.name}
          </h4>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <MapPin className="h-4 w-4" />
            <span data-testid="business-address">{business.address}</span>
          </div>
          {business.phone && (
            <div className="flex items-center space-x-2 text-sm text-gray-600 mt-1">
              <Phone className="h-4 w-4" />
              <span data-testid="business-phone">{business.phone}</span>
            </div>
          )}
          {business.website && (
            <div className="flex items-center space-x-2 text-sm text-gray-600 mt-1">
              <Globe className="h-4 w-4" />
              <a 
                href={business.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
                data-testid="business-website"
              >
                Visit Website
              </a>
            </div>
          )}
          <div className="flex items-center space-x-2 mt-2">
            <Badge 
              variant={business.isClaimed ? "default" : "secondary"}
              className={business.isClaimed ? "bg-secondary text-green-800" : "bg-warning text-yellow-800"}
              data-testid="business-claim-status"
            >
              {business.isClaimed ? "Claimed" : "Unclaimed"}
            </Badge>
            <Badge variant="outline" data-testid="business-type">
              {business.businessType}
            </Badge>
            <span className="text-xs text-gray-500" data-testid="business-discovered-time">
              {formatDistanceToNow(new Date(business.discoveredAt!), { addSuffix: true })}
            </span>
          </div>
        </div>
      </div>
      
      {showActions && (
        <div className="flex space-x-2">
          {!business.isClaimed && (
            <>
              <Button
                onClick={() => onCreatePackage?.(business)}
                size="sm"
                className="bg-primary text-white hover:bg-blue-700 transition-colors"
                data-testid="button-create-package"
              >
                Create Package
              </Button>
              <Button
                onClick={() => onSendEmail?.(business)}
                size="sm"
                variant="outline"
                data-testid="button-send-email"
              >
                Send Email
              </Button>
            </>
          )}
          {business.isClaimed && (
            <Button
              disabled
              size="sm"
              variant="outline"
              className="cursor-not-allowed"
              data-testid="button-already-claimed"
            >
              Already Claimed
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

import { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Business } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface PackageComponent {
  name: string;
  price: number;
  description?: string;
}

interface PackageModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  business?: Business;
}

export default function PackageModal({ open, onOpenChange, business }: PackageModalProps) {
  const [selectedComponents, setSelectedComponents] = useState<string[]>([]);
  const [customMessage, setCustomMessage] = useState("");
  const [totalPrice, setTotalPrice] = useState(0);
  const { toast } = useToast();

  // Get available components for business type
  const { data: components = [], isLoading } = useQuery({
    queryKey: ["/api/packages/components", business?.businessType],
    enabled: !!business?.businessType && open,
  });



  // Create package mutation
  const createPackageMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/packages/custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessId: business?.id,
          components: selectedComponents,
          customMessage,
        }),
      });
      if (!response.ok) throw new Error("Failed to create package");
      return response.json();
    },
    onSuccess: async (packageData) => {
      // Generate email for the package
      const emailResponse = await fetch("/api/generate-package-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessId: business?.id,
          packageId: packageData.id,
          customMessage,
        }),
      });
      
      if (emailResponse.ok) {
        const emailData = await emailResponse.json();
        console.log("Generated email:", emailData);
        
        toast({
          title: "Package Created Successfully",
          description: "Package and email template have been generated.",
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ["/api/businesses"] });
      onOpenChange(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create package. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Reset form when modal closes
  useEffect(() => {
    if (!open) {
      resetForm();
    } else if (business && components.length > 0 && selectedComponents.length === 0) {
      // Set default components (first 2) only when modal opens and no components are selected
      const defaultComponents = (components as PackageComponent[]).slice(0, 2).map((c: PackageComponent) => c.name);
      setSelectedComponents(defaultComponents);
    }
  }, [open, business]); // Removed components from dependency array

  // Calculate price callback
  const calculatePrice = useCallback(async (components: string[], businessType: string) => {
    if (components.length === 0) {
      setTotalPrice(0);
      return;
    }
    
    try {
      const response = await fetch("/api/packages/calculate-price", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ components, businessType }),
      });
      if (response.ok) {
        const data = await response.json();
        setTotalPrice(data.price);
      }
    } catch (error) {
      console.error("Failed to calculate price:", error);
      setTotalPrice(0);
    }
  }, []);

  // Recalculate price when components change
  useEffect(() => {
    if (business?.businessType) {
      calculatePrice(selectedComponents, business.businessType);
    }
  }, [selectedComponents, business?.businessType, calculatePrice]);

  const resetForm = () => {
    setSelectedComponents([]);
    setCustomMessage("");
    setTotalPrice(0);
  };

  const handleComponentChange = (componentName: string, checked: boolean) => {
    if (checked) {
      setSelectedComponents(prev => [...prev, componentName]);
    } else {
      setSelectedComponents(prev => prev.filter(name => name !== componentName));
    }
  };

  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(2)}`;
  };

  if (!business) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="package-modal">
        <DialogHeader>
          <DialogTitle data-testid="modal-title">Create Custom Package</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Business Information</label>
            <div className="bg-gray-50 p-4 rounded-md" data-testid="business-info">
              <h4 className="font-medium text-gray-900" data-testid="business-name">
                {business.name}
              </h4>
              <p className="text-sm text-gray-600" data-testid="business-address">
                {business.address}
              </p>
              <p className="text-sm text-gray-600" data-testid="business-type">
                {business.businessType}
              </p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Package Components</label>
            {isLoading ? (
              <div className="text-sm text-gray-500">Loading components...</div>
            ) : (
              <div className="space-y-3" data-testid="component-list">
                {components.map((component: PackageComponent) => (
                  <label key={component.name} className="flex items-start space-x-3">
                    <Checkbox
                      checked={selectedComponents.includes(component.name)}
                      onCheckedChange={(checked) => 
                        handleComponentChange(component.name, checked as boolean)
                      }
                      data-testid={`checkbox-${component.name.toLowerCase().replace(/\s+/g, '-')}`}
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-700">{component.name}</span>
                        <Badge variant="outline" data-testid={`price-${component.name.toLowerCase().replace(/\s+/g, '-')}`}>
                          {formatPrice(component.price)}
                        </Badge>
                      </div>
                      {component.description && (
                        <p className="text-xs text-gray-500 mt-1">{component.description}</p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Custom Message</label>
            <Textarea
              rows={4}
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="Add a personalized message for this business..."
              data-testid="textarea-custom-message"
            />
          </div>

          <div className="bg-gray-50 p-4 rounded-md">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-700">Total Package Value:</span>
              <span className="text-lg font-bold text-primary" data-testid="total-price">
                {formatPrice(totalPrice)}
              </span>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button
            onClick={() => createPackageMutation.mutate()}
            disabled={selectedComponents.length === 0 || createPackageMutation.isPending}
            data-testid="button-generate-package"
          >
            {createPackageMutation.isPending ? "Creating..." : "Generate Package & Email"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

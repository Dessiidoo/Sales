import { Link, useLocation } from "wouter";
import { 
  Search, 
  Building, 
  Package, 
  Mail, 
  BarChart3, 
  ChartLine,
  Plus,
  Download,
  MapPin
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();

  const navigationItems = [
    {
      name: "Dashboard",
      href: "/",
      icon: ChartLine,
      current: location === "/",
    },
    {
      name: "Business Discovery",
      href: "/business-discovery",
      icon: Search,
      current: location === "/business-discovery",
    },
    {
      name: "Found Businesses",
      href: "/found-businesses",
      icon: Building,
      current: location === "/found-businesses",
    },
    {
      name: "Manual Entry",
      href: "/manual-entry",
      icon: Plus,
      current: location === "/manual-entry",
    },
    {
      name: "Package Builder",
      href: "/package-builder",
      icon: Package,
      current: location === "/package-builder",
    },
    {
      name: "Email Templates",
      href: "/email-templates",
      icon: Mail,
      current: location === "/email-templates",
    },
    {
      name: "Analytics",
      href: "/analytics",
      icon: BarChart3,
      current: location === "/analytics",
    },
  ];

  const quickActions = [
    {
      name: "New Search",
      icon: Plus,
      onClick: () => {
        // Navigate to business discovery
        window.location.href = "/business-discovery";
      },
    },
    {
      name: "Export Leads",
      icon: Download,
      onClick: () => {
        // TODO: Implement export functionality
        console.log("Export leads");
      },
    },
  ];

  return (
    <div className="w-64 bg-white shadow-sm border-r border-gray-200" data-testid="sidebar">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <MapPin className="h-8 w-8 text-primary" data-testid="logo-icon" />
          <h1 className="text-xl font-bold text-gray-900" data-testid="app-title">
            JeoSync
          </h1>
        </div>
      </div>
      
      <nav className="mt-6">
        <div className="px-3">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                  item.current
                    ? "text-white bg-primary"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                )}
                data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.name}
              </Link>
            );
          })}
        </div>
        
        <div className="px-3 mt-8">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            Quick Actions
          </h3>
          <div className="mt-2 space-y-1">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.name}
                  onClick={action.onClick}
                  className="w-full text-left flex items-center px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-md transition-colors"
                  data-testid={`action-${action.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {action.name}
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}

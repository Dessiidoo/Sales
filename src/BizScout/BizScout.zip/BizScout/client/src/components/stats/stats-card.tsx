import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  subtitle?: string;
  iconColor?: string;
}

export default function StatsCard({ title, value, icon: Icon, subtitle, iconColor = "text-primary" }: StatsCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6" data-testid={`stats-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex items-center">
        <div className="flex-shrink-0">
          <Icon className={`h-8 w-8 ${iconColor}`} />
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-gray-600" data-testid="stats-title">
            {title}
          </p>
          <p className="text-2xl font-bold text-gray-900" data-testid="stats-value">
            {value}
          </p>
        </div>
      </div>
      {subtitle && (
        <div className="mt-2">
          <span className="text-xs text-secondary" data-testid="stats-subtitle">
            {subtitle}
          </span>
        </div>
      )}
    </div>
  );
}

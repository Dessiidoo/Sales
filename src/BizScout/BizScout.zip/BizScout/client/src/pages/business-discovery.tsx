import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Search, MapPin, Clock, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

interface SearchJob {
  id: string;
  businessType: string;
  location: string;
  radius: number;
  status: string;
  businessesFound: number;
  unclaimedFound: number;
  errorMessage?: string;
  createdAt: string;
  completedAt?: string;
}

export default function BusinessDiscovery() {
  const [searchForm, setSearchForm] = useState({
    businessType: "",
    location: "",
    radius: "25",
  });
  const { toast } = useToast();

  // Fetch business types
  const { data: businessTypes = [] } = useQuery({
    queryKey: ["/api/business-types"],
  });

  // Fetch search jobs
  const { data: searchJobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/search/jobs"],
  });

  // Search mutation
  const searchMutation = useMutation({
    mutationFn: async (searchData: typeof searchForm) => {
      const response = await fetch("/api/search/businesses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessType: searchData.businessType,
          location: searchData.location,
          radius: parseInt(searchData.radius),
        }),
      });
      if (!response.ok) throw new Error("Failed to start search");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Search Started",
        description: "Your business discovery search has been initiated. Results will appear shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/search/jobs"] });
      setSearchForm({ businessType: "", location: "", radius: "25" });
    },
    onError: (error) => {
      toast({
        title: "Search Failed",
        description: error.message || "Failed to start business search. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    if (!searchForm.businessType || !searchForm.location) {
      toast({
        title: "Missing Information",
        description: "Please select a business type and enter a location.",
        variant: "destructive",
      });
      return;
    }

    searchMutation.mutate(searchForm);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'running':
        return <Clock className="h-5 w-5 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'running':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <>
      <Header
        title="Business Discovery"
        subtitle="Search for local businesses and identify unclaimed listings"
        showSearchButton={false}
      />

      <main className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Search Form */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center" data-testid="search-form-title">
                  <Search className="mr-2 h-5 w-5" />
                  New Business Search
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Business Type *
                  </label>
                  <Select 
                    value={searchForm.businessType} 
                    onValueChange={(value) => setSearchForm(prev => ({...prev, businessType: value}))}
                  >
                    <SelectTrigger data-testid="select-business-type">
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent>
                      {businessTypes.map((type: string) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Location *
                  </label>
                  <Input
                    type="text"
                    placeholder="City, State or ZIP code"
                    value={searchForm.location}
                    onChange={(e) => setSearchForm(prev => ({...prev, location: e.target.value}))}
                    data-testid="input-location"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Search Radius
                  </label>
                  <Select 
                    value={searchForm.radius} 
                    onValueChange={(value) => setSearchForm(prev => ({...prev, radius: value}))}
                  >
                    <SelectTrigger data-testid="select-radius">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 miles</SelectItem>
                      <SelectItem value="10">10 miles</SelectItem>
                      <SelectItem value="25">25 miles</SelectItem>
                      <SelectItem value="50">50 miles</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button 
                  onClick={handleSearch}
                  disabled={searchMutation.isPending || !searchForm.businessType || !searchForm.location}
                  className="w-full"
                  data-testid="button-start-search"
                >
                  {searchMutation.isPending ? (
                    <>
                      <Clock className="mr-2 h-4 w-4 animate-spin" />
                      Starting Search...
                    </>
                  ) : (
                    <>
                      <Search className="mr-2 h-4 w-4" />
                      Start Search
                    </>
                  )}
                </Button>

                <div className="text-xs text-gray-500 mt-4">
                  <p>💡 Tips for better results:</p>
                  <ul className="list-disc list-inside space-y-1 mt-2">
                    <li>Use specific business types</li>
                    <li>Try different radius sizes</li>
                    <li>Include nearby suburbs</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search Results */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle data-testid="search-history-title">Search History</CardTitle>
              </CardHeader>
              <CardContent>
                {jobsLoading ? (
                  <div className="text-center py-8">
                    <div className="text-sm text-gray-500">Loading search history...</div>
                  </div>
                ) : searchJobs.length === 0 ? (
                  <div className="text-center py-8">
                    <Search className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No searches yet</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Start your first business discovery search to see results here.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {searchJobs.map((job: SearchJob) => (
                      <div
                        key={job.id}
                        className="border border-gray-200 rounded-lg p-4"
                        data-testid={`search-job-${job.id}`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            {getStatusIcon(job.status)}
                            <div>
                              <h4 className="font-medium text-gray-900" data-testid="job-title">
                                {job.businessType} in {job.location}
                              </h4>
                              <div className="flex items-center space-x-2 text-sm text-gray-500">
                                <MapPin className="h-4 w-4" />
                                <span>{job.radius} mile radius</span>
                                <span>•</span>
                                <span data-testid="job-time">
                                  {formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}
                                </span>
                              </div>
                            </div>
                          </div>
                          <Badge className={getStatusColor(job.status)} data-testid="job-status">
                            {job.status}
                          </Badge>
                        </div>

                        {job.status === 'running' && (
                          <div className="mb-3">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-sm text-gray-600">Searching...</span>
                              <span className="text-sm text-gray-500">In Progress</span>
                            </div>
                            <Progress value={50} className="w-full" />
                          </div>
                        )}

                        {job.status === 'completed' && (
                          <div className="grid grid-cols-2 gap-4 mb-3">
                            <div className="text-center p-3 bg-blue-50 rounded-lg">
                              <div className="text-2xl font-bold text-blue-600" data-testid="businesses-found">
                                {job.businessesFound}
                              </div>
                              <div className="text-sm text-blue-600">Businesses Found</div>
                            </div>
                            <div className="text-center p-3 bg-green-50 rounded-lg">
                              <div className="text-2xl font-bold text-green-600" data-testid="unclaimed-found">
                                {job.unclaimedFound}
                              </div>
                              <div className="text-sm text-green-600">Unclaimed Listings</div>
                            </div>
                          </div>
                        )}

                        {job.status === 'failed' && job.errorMessage && (
                          <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                            <p className="text-sm text-red-700" data-testid="error-message">
                              <strong>Error:</strong> {job.errorMessage}
                            </p>
                          </div>
                        )}

                        {job.status === 'completed' && job.businessesFound > 0 && (
                          <div className="mt-3">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => window.location.href = `/found-businesses?search=${job.id}`}
                              data-testid="button-view-results"
                            >
                              View Results
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </>
  );
}

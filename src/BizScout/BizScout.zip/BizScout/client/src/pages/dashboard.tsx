import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import StatsCard from "@/components/stats/stats-card";
import BusinessCard from "@/components/business/business-card";
import PackageModal from "@/components/business/package-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Building, MapPin, Mail, Handshake, Search } from "lucide-react";
import { useState } from "react";
import { Business } from "@shared/schema";
import { Link } from "wouter";

export default function Dashboard() {
  const [selectedBusiness, setSelectedBusiness] = useState<Business | undefined>();
  const [packageModalOpen, setPackageModalOpen] = useState(false);
  const [searchForm, setSearchForm] = useState({
    businessType: "",
    location: "",
    radius: "25",
  });

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  // Fetch recent businesses
  const { data: businesses = [], isLoading: businessesLoading } = useQuery({
    queryKey: ["/api/businesses"],
  });

  // Fetch package templates
  const { data: packageTemplates = [], isLoading: packagesLoading } = useQuery({
    queryKey: ["/api/packages/templates"],
  });

  // Fetch business types
  const { data: businessTypes = [] } = useQuery({
    queryKey: ["/api/business-types"],
  });

  const recentBusinesses = businesses.slice(0, 3);

  const handleCreatePackage = (business: Business) => {
    setSelectedBusiness(business);
    setPackageModalOpen(true);
  };

  const handleSendEmail = (business: Business) => {
    // TODO: Implement direct email functionality
    console.log("Send email to:", business);
  };

  const handleStartSearch = () => {
    // TODO: Implement search functionality
    console.log("Starting search with:", searchForm);
  };

  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(2)}`;
  };

  return (
    <>
      <Header
        title="Dashboard"
        subtitle="Discover and manage local business opportunities"
        onSearch={() => console.log("Navigate to search")}
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Businesses Found"
            value={stats?.businessesFound || 0}
            icon={Building}
            subtitle="+12.5% from last week"
          />
          <StatsCard
            title="Unclaimed Listings"
            value={stats?.unclaimedListings || 0}
            icon={MapPin}
            subtitle={`${stats ? Math.round((stats.unclaimedListings / Math.max(stats.businessesFound, 1)) * 100) : 0}% of total found`}
            iconColor="text-warning"
          />
          <StatsCard
            title="Emails Sent"
            value={stats?.emailsSent || 0}
            icon={Mail}
            subtitle="48% response rate"
            iconColor="text-secondary"
          />
          <StatsCard
            title="Conversions"
            value={stats?.conversions || 0}
            icon={Handshake}
            subtitle="14.7% conversion rate"
            iconColor="text-secondary"
          />
        </div>

        {/* Search Panel and Recent Discoveries */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Quick Search Panel */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle data-testid="quick-search-title">Quick Search</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Business Type
                  </label>
                  <Select 
                    value={searchForm.businessType} 
                    onValueChange={(value) => setSearchForm(prev => ({...prev, businessType: value}))}
                  >
                    <SelectTrigger data-testid="select-business-type">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {businessTypes.map((type: string) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Location
                  </label>
                  <Input
                    type="text"
                    placeholder="City, State or ZIP code"
                    value={searchForm.location}
                    onChange={(e) => setSearchForm(prev => ({...prev, location: e.target.value}))}
                    data-testid="input-location"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Search Radius
                  </label>
                  <Select 
                    value={searchForm.radius} 
                    onValueChange={(value) => setSearchForm(prev => ({...prev, radius: value}))}
                  >
                    <SelectTrigger data-testid="select-radius">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 miles</SelectItem>
                      <SelectItem value="10">10 miles</SelectItem>
                      <SelectItem value="25">25 miles</SelectItem>
                      <SelectItem value="50">50 miles</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Link href="/business-discovery">
                  <Button className="w-full" data-testid="button-start-search-dashboard">
                    <Search className="mr-2 h-4 w-4" />
                    Start Search
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Recent Discoveries */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle data-testid="recent-discoveries-title">Recent Discoveries</CardTitle>
                  <Link href="/found-businesses" className="text-sm text-primary hover:text-blue-700">
                    View all
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {businessesLoading ? (
                  <div className="text-sm text-gray-500">Loading businesses...</div>
                ) : recentBusinesses.length === 0 ? (
                  <div className="text-center py-8">
                    <Building className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No businesses found yet</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Start your first search to discover local businesses.
                    </p>
                    <div className="mt-6">
                      <Link href="/business-discovery">
                        <Button>
                          <Search className="mr-2 h-4 w-4" />
                          Start Discovery
                        </Button>
                      </Link>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentBusinesses.map((business: Business) => (
                      <BusinessCard
                        key={business.id}
                        business={business}
                        onCreatePackage={handleCreatePackage}
                        onSendEmail={handleSendEmail}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Package Templates and Performance Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Package Templates */}
          <Card>
            <CardHeader>
              <CardTitle data-testid="package-templates-title">Popular Package Templates</CardTitle>
            </CardHeader>
            <CardContent>
              {packagesLoading ? (
                <div className="text-sm text-gray-500">Loading templates...</div>
              ) : (
                <div className="space-y-4">
                  {packageTemplates.map((template: any) => (
                    <div
                      key={template.id}
                      className="border border-gray-200 rounded-lg p-4 hover:border-primary transition-colors cursor-pointer"
                      data-testid={`template-${template.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">{template.name}</h4>
                        <span className="text-sm font-medium text-primary">
                          {formatPrice(template.price)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {Array.isArray(template.components) && template.components.slice(0, 3).map((component: any, index: number) => (
                          <span
                            key={index}
                            className="inline-flex items-center px-2 py-1 rounded text-xs bg-blue-100 text-blue-800"
                          >
                            {component.name}
                          </span>
                        ))}
                        {Array.isArray(template.components) && template.components.length > 3 && (
                          <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-600">
                            +{template.components.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Performance Analytics */}
          <Card>
            <CardHeader>
              <CardTitle data-testid="performance-overview-title">Performance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-600">Search Success Rate</span>
                    <span className="text-sm font-medium text-gray-900" data-testid="search-success-rate">87%</span>
                  </div>
                  <Progress value={87} className="w-full" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-600">Email Response Rate</span>
                    <span className="text-sm font-medium text-gray-900" data-testid="email-response-rate">48%</span>
                  </div>
                  <Progress value={48} className="w-full" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-600">Conversion Rate</span>
                    <span className="text-sm font-medium text-gray-900" data-testid="conversion-rate">14.7%</span>
                  </div>
                  <Progress value={14.7} className="w-full" />
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Top Performing Business Types</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Landscaping</span>
                      <span className="font-medium text-gray-900" data-testid="landscaping-unclaimed">32% unclaimed</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Hair Salons</span>
                      <span className="font-medium text-gray-900" data-testid="hair-salons-unclaimed">28% unclaimed</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Cleaning Services</span>
                      <span className="font-medium text-gray-900" data-testid="cleaning-services-unclaimed">24% unclaimed</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <PackageModal
        open={packageModalOpen}
        onOpenChange={setPackageModalOpen}
        business={selectedBusiness}
      />
    </>
  );
}

import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Plus, Edit, Trash2, Eye, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  businessType: string | null;
  isDefault: boolean;
  createdAt: string;
}

export default function EmailTemplates() {
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | undefined>();
  const [formData, setFormData] = useState({
    name: "",
    subject: "",
    content: "",
    businessType: "",
    isDefault: false,
  });
  const { toast } = useToast();

  // Fetch email templates
  const { data: templates = [], isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/email-templates"],
  });

  // Fetch business types
  const { data: businessTypes = [] } = useQuery({
    queryKey: ["/api/business-types"],
  });

  // Fetch email variables
  const { data: emailVariables = [] } = useQuery({
    queryKey: ["/api/email-variables"],
  });

  // Create template mutation
  const createTemplateMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/email-templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          subject: formData.subject,
          content: formData.content,
          businessType: formData.businessType || null,
          isDefault: formData.isDefault,
        }),
      });
      if (!response.ok) throw new Error("Failed to create template");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Template Created",
        description: "Your email template has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/email-templates"] });
      setCreateModalOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create email template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      subject: "",
      content: "",
      businessType: "",
      isDefault: false,
    });
  };

  const handlePreview = (template: EmailTemplate) => {
    setSelectedTemplate(template);
    setPreviewModalOpen(true);
  };

  const handleCopyTemplate = (template: EmailTemplate) => {
    setFormData({
      name: `Copy of ${template.name}`,
      subject: template.subject,
      content: template.content,
      businessType: template.businessType || "",
      isDefault: false,
    });
    setCreateModalOpen(true);
  };

  const insertVariable = (variable: string) => {
    setFormData(prev => ({
      ...prev,
      content: prev.content + `{${variable}}`
    }));
  };

  const defaultTemplate = (templates as EmailTemplate[]).find((t: EmailTemplate) => t.isDefault);
  const customTemplates = (templates as EmailTemplate[]).filter((t: EmailTemplate) => !t.isDefault);

  const previewContent = (content: string) => {
    // Replace variables with sample data for preview
    const sampleData: { [key: string]: string } = {
      businessName: "Sunrise Hair Studio",
      ownerName: "Sarah Johnson",
      businessType: "Hair Salon",
      address: "123 Main St, Austin, TX",
      packageName: "Complete SEO Package",
      packagePrice: "$599.00",
      senderName: "Local Business Expert",
      senderCompany: "LocalBiz Finder",
      senderPhone: "(555) 123-4567",
      senderEmail: "expert@localbizfinder.com",
      customMessage: "I noticed your business has great potential for online growth.",
    };

    let preview = content;
    Object.entries(sampleData).forEach(([key, value]) => {
      const regex = new RegExp(`{${key}}`, 'g');
      preview = preview.replace(regex, value);
    });

    // Handle component list
    preview = preview.replace('{packageComponentsList}', '• Google Business Profile Setup\n• Professional Photos\n• Review Management');

    return preview;
  };

  return (
    <>
      <Header
        title="Email Templates"
        subtitle="Create and manage email templates for business outreach"
        showSearchButton={false}
      />

      <main className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Create Template Panel */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center" data-testid="create-template-title">
                  <Plus className="mr-2 h-5 w-5" />
                  Quick Create
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Dialog open={createModalOpen} onOpenChange={setCreateModalOpen}>
                  <DialogTrigger asChild>
                    <Button className="w-full" data-testid="button-create-new-template">
                      <Plus className="mr-2 h-4 w-4" />
                      New Email Template
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="create-template-modal">
                    <DialogHeader>
                      <DialogTitle>Create New Email Template</DialogTitle>
                    </DialogHeader>
                    
                    <div className="grid grid-cols-2 gap-6">
                      {/* Form */}
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Template Name *
                            </label>
                            <Input
                              value={formData.name}
                              onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                              placeholder="e.g., General Business Outreach"
                              data-testid="input-template-name"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Business Type
                            </label>
                            <Select 
                              value={formData.businessType} 
                              onValueChange={(value) => setFormData(prev => ({...prev, businessType: value}))}
                            >
                              <SelectTrigger data-testid="select-business-type">
                                <SelectValue placeholder="All Business Types" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="all">All Business Types</SelectItem>
                                {(businessTypes as string[]).map((type: string) => (
                                  <SelectItem key={type} value={type}>
                                    {type}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Email Subject *
                          </label>
                          <Input
                            value={formData.subject}
                            onChange={(e) => setFormData(prev => ({...prev, subject: e.target.value}))}
                            placeholder="e.g., Improve Your {businessType} Business - Free Analysis"
                            data-testid="input-template-subject"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Email Content *
                          </label>
                          <Textarea
                            value={formData.content}
                            onChange={(e) => setFormData(prev => ({...prev, content: e.target.value}))}
                            placeholder="Write your email content here. Use variables like {businessName}, {businessType}, etc."
                            rows={12}
                            data-testid="textarea-template-content"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Available Variables
                          </label>
                          <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                            {(emailVariables as string[]).map((variable: string) => (
                              <Button
                                key={variable}
                                size="sm"
                                variant="outline"
                                onClick={() => insertVariable(variable)}
                                className="text-xs"
                                data-testid={`button-variable-${variable}`}
                              >
                                {`{${variable}}`}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Preview */}
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-700 mb-2">Live Preview</h4>
                          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 max-h-96 overflow-y-auto">
                            <div className="mb-3">
                              <strong>Subject:</strong> {previewContent(formData.subject)}
                            </div>
                            <div className="whitespace-pre-wrap text-sm" data-testid="email-preview">
                              {previewContent(formData.content)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end space-x-3 pt-4">
                      <Button
                        variant="outline"
                        onClick={() => setCreateModalOpen(false)}
                        data-testid="button-cancel-create"
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={() => createTemplateMutation.mutate()}
                        disabled={!formData.name || !formData.subject || !formData.content || createTemplateMutation.isPending}
                        data-testid="button-save-template"
                      >
                        {createTemplateMutation.isPending ? "Creating..." : "Create Template"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <div className="mt-6 space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Quick Stats</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Total Templates</span>
                        <span className="font-medium" data-testid="stat-total-templates">
                          {(templates as EmailTemplate[]).length}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Default Template</span>
                        <span className="font-medium" data-testid="stat-default-template">
                          {defaultTemplate ? "Set" : "None"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Tips</h4>
                    <div className="text-xs text-gray-500 space-y-1">
                      <p>• Use variables for personalization</p>
                      <p>• Keep subject lines under 50 characters</p>
                      <p>• Test templates before sending</p>
                      <p>• Include clear call-to-action</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Templates List */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle data-testid="templates-list-title">Email Templates</CardTitle>
              </CardHeader>
              <CardContent>
                {templatesLoading ? (
                  <div className="text-center py-8">
                    <div className="text-sm text-gray-500">Loading email templates...</div>
                  </div>
                ) : (templates as EmailTemplate[]).length === 0 ? (
                  <div className="text-center py-8">
                    <Mail className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No email templates</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Create your first email template to get started.
                    </p>
                  </div>
                ) : (
                  <Tabs defaultValue="all" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="all" data-testid="tab-all">
                        All ({(templates as EmailTemplate[]).length})
                      </TabsTrigger>
                      <TabsTrigger value="default" data-testid="tab-default">
                        Default ({defaultTemplate ? 1 : 0})
                      </TabsTrigger>
                      <TabsTrigger value="custom" data-testid="tab-custom">
                        Custom ({customTemplates.length})
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="all" className="mt-6">
                      <div className="space-y-4">
                        {(templates as EmailTemplate[]).map((template: EmailTemplate) => (
                          <TemplateCard
                            key={template.id}
                            template={template}
                            onPreview={handlePreview}
                            onCopy={handleCopyTemplate}
                          />
                        ))}
                      </div>
                    </TabsContent>

                    <TabsContent value="default" className="mt-6">
                      <div className="space-y-4">
                        {defaultTemplate ? (
                          <TemplateCard
                            template={defaultTemplate}
                            onPreview={handlePreview}
                            onCopy={handleCopyTemplate}
                          />
                        ) : (
                          <div className="text-center py-8">
                            <Mail className="mx-auto h-12 w-12 text-gray-400" />
                            <h3 className="mt-2 text-sm font-medium text-gray-900">No default template</h3>
                            <p className="mt-1 text-sm text-gray-500">
                              Set a template as default for automatic use.
                            </p>
                          </div>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="custom" className="mt-6">
                      <div className="space-y-4">
                        {customTemplates.length === 0 ? (
                          <div className="text-center py-8">
                            <Mail className="mx-auto h-12 w-12 text-gray-400" />
                            <h3 className="mt-2 text-sm font-medium text-gray-900">No custom templates</h3>
                            <p className="mt-1 text-sm text-gray-500">
                              Create custom templates for specific business types.
                            </p>
                          </div>
                        ) : (
                          customTemplates.map((template: EmailTemplate) => (
                            <TemplateCard
                              key={template.id}
                              template={template}
                              onPreview={handlePreview}
                              onCopy={handleCopyTemplate}
                            />
                          ))
                        )}
                      </div>
                    </TabsContent>
                  </Tabs>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Preview Modal */}
      <Dialog open={previewModalOpen} onOpenChange={setPreviewModalOpen}>
        <DialogContent className="max-w-2xl" data-testid="preview-modal">
          <DialogHeader>
            <DialogTitle>Email Template Preview</DialogTitle>
          </DialogHeader>
          
          {selectedTemplate && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900" data-testid="preview-name">
                  {selectedTemplate.name}
                </h3>
                <div className="flex items-center space-x-2 mt-2">
                  {selectedTemplate.isDefault && (
                    <Badge className="bg-green-100 text-green-800">Default</Badge>
                  )}
                  {selectedTemplate.businessType && (
                    <Badge variant="outline" data-testid="preview-business-type">
                      {selectedTemplate.businessType}
                    </Badge>
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-2">Subject Line</h4>
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm" data-testid="preview-subject">
                    {previewContent(selectedTemplate.subject)}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-2">Email Content</h4>
                <div className="p-4 bg-gray-50 rounded-lg border max-h-96 overflow-y-auto">
                  <div className="whitespace-pre-wrap text-sm" data-testid="preview-content">
                    {previewContent(selectedTemplate.content)}
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4">
            <Button
              variant="outline"
              onClick={() => selectedTemplate && handleCopyTemplate(selectedTemplate)}
              data-testid="button-copy-template"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copy Template
            </Button>
            <Button
              onClick={() => setPreviewModalOpen(false)}
              data-testid="button-close-preview"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Template Card Component
function TemplateCard({ 
  template, 
  onPreview, 
  onCopy 
}: { 
  template: EmailTemplate; 
  onPreview: (template: EmailTemplate) => void;
  onCopy: (template: EmailTemplate) => void;
}) {
  return (
    <div
      className="border border-gray-200 rounded-lg p-4 hover:border-primary transition-colors"
      data-testid={`template-card-${template.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <h4 className="font-medium text-gray-900" data-testid="template-name">
              {template.name}
            </h4>
            {template.isDefault && (
              <Badge className="bg-green-100 text-green-800">Default</Badge>
            )}
          </div>
          <p className="text-sm text-gray-600 mb-2" data-testid="template-subject">
            <strong>Subject:</strong> {template.subject}
          </p>
          {template.businessType && (
            <Badge variant="outline" data-testid="template-business-type">
              {template.businessType}
            </Badge>
          )}
        </div>
      </div>

      <div className="bg-gray-50 p-3 rounded-lg mb-3">
        <p className="text-sm text-gray-700 line-clamp-3" data-testid="template-content-preview">
          {template.content.slice(0, 150)}...
        </p>
      </div>

      <div className="flex justify-end space-x-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => onPreview(template)}
          data-testid="button-preview-template"
        >
          <Eye className="h-4 w-4 mr-1" />
          Preview
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => onCopy(template)}
          data-testid="button-copy-template"
        >
          <Copy className="h-4 w-4 mr-1" />
          Copy
        </Button>
        <Button
          size="sm"
          variant="outline"
          data-testid="button-edit-template"
        >
          <Edit className="h-4 w-4 mr-1" />
          Edit
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="text-red-600 hover:text-red-700"
          data-testid="button-delete-template"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import BusinessCard from "@/components/business/business-card";
import PackageModal from "@/components/business/package-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building, MapPin, Download, Filter } from "lucide-react";
import { Business } from "@shared/schema";

export default function FoundBusinesses() {
  const [selectedBusiness, setSelectedBusiness] = useState<Business | undefined>();
  const [packageModalOpen, setPackageModalOpen] = useState(false);
  const [filters, setFilters] = useState({
    businessType: "",
    city: "",
    claimStatus: "all",
    searchQuery: "",
  });

  // Fetch businesses
  const { data: allBusinesses = [], isLoading: businessesLoading } = useQuery({
    queryKey: ["/api/businesses"],
  });

  // Fetch business types for filter
  const { data: businessTypes = [] } = useQuery({
    queryKey: ["/api/business-types"],
  });

  // Filter businesses based on current filters
  const filteredBusinesses = allBusinesses.filter((business: Business) => {
    if (filters.businessType && business.businessType !== filters.businessType) return false;
    if (filters.city && !business.city.toLowerCase().includes(filters.city.toLowerCase())) return false;
    if (filters.claimStatus === "claimed" && !business.isClaimed) return false;
    if (filters.claimStatus === "unclaimed" && business.isClaimed) return false;
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      return (
        business.name.toLowerCase().includes(query) ||
        business.address.toLowerCase().includes(query) ||
        business.businessType.toLowerCase().includes(query)
      );
    }
    return true;
  });

  const unclaimedBusinesses = filteredBusinesses.filter((b: Business) => !b.isClaimed);
  const claimedBusinesses = filteredBusinesses.filter((b: Business) => b.isClaimed);

  // Get unique cities for filter
  const cities = Array.from(new Set(allBusinesses.map((b: Business) => b.city))).filter(Boolean);

  const handleCreatePackage = (business: Business) => {
    setSelectedBusiness(business);
    setPackageModalOpen(true);
  };

  const handleSendEmail = (business: Business) => {
    // TODO: Implement direct email functionality
    console.log("Send email to:", business);
  };

  const handleExport = () => {
    // TODO: Implement export functionality
    console.log("Export businesses:", filteredBusinesses);
  };

  const clearFilters = () => {
    setFilters({
      businessType: "",
      city: "",
      claimStatus: "all",
      searchQuery: "",
    });
  };

  return (
    <>
      <Header
        title="Found Businesses"
        subtitle="Manage discovered businesses and track outreach efforts"
        showSearchButton={false}
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Filters and Stats */}
        <div className="mb-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            {/* Search */}
            <div>
              <Input
                placeholder="Search businesses..."
                value={filters.searchQuery}
                onChange={(e) => setFilters(prev => ({...prev, searchQuery: e.target.value}))}
                data-testid="input-search-businesses"
              />
            </div>

            {/* Business Type Filter */}
            <div>
              <Select 
                value={filters.businessType} 
                onValueChange={(value) => setFilters(prev => ({...prev, businessType: value}))}
              >
                <SelectTrigger data-testid="select-filter-business-type">
                  <SelectValue placeholder="All Business Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Business Types</SelectItem>
                  {businessTypes.map((type: string) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* City Filter */}
            <div>
              <Select 
                value={filters.city} 
                onValueChange={(value) => setFilters(prev => ({...prev, city: value}))}
              >
                <SelectTrigger data-testid="select-filter-city">
                  <SelectValue placeholder="All Cities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {cities.map((city: string) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Actions */}
            <div className="flex space-x-2">
              <Button variant="outline" onClick={clearFilters} data-testid="button-clear-filters">
                <Filter className="mr-2 h-4 w-4" />
                Clear
              </Button>
              <Button variant="outline" onClick={handleExport} data-testid="button-export">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Found</p>
                    <p className="text-2xl font-bold text-gray-900" data-testid="stat-total-found">
                      {filteredBusinesses.length}
                    </p>
                  </div>
                  <Building className="h-8 w-8 text-gray-400" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Unclaimed</p>
                    <p className="text-2xl font-bold text-warning" data-testid="stat-unclaimed">
                      {unclaimedBusinesses.length}
                    </p>
                  </div>
                  <MapPin className="h-8 w-8 text-warning" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Success Rate</p>
                    <p className="text-2xl font-bold text-secondary" data-testid="stat-success-rate">
                      {filteredBusinesses.length > 0 
                        ? Math.round((unclaimedBusinesses.length / filteredBusinesses.length) * 100) 
                        : 0}%
                    </p>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                    <span className="text-white text-xs font-bold">%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Business List */}
        <Card>
          <CardHeader>
            <CardTitle data-testid="businesses-list-title">Discovered Businesses</CardTitle>
          </CardHeader>
          <CardContent>
            {businessesLoading ? (
              <div className="text-center py-8">
                <div className="text-sm text-gray-500">Loading businesses...</div>
              </div>
            ) : filteredBusinesses.length === 0 ? (
              <div className="text-center py-8">
                <Building className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No businesses found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  {allBusinesses.length === 0 
                    ? "Start a business discovery search to find local businesses."
                    : "Try adjusting your filters to see more results."
                  }
                </p>
              </div>
            ) : (
              <Tabs defaultValue="unclaimed" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="unclaimed" data-testid="tab-unclaimed">
                    Unclaimed ({unclaimedBusinesses.length})
                  </TabsTrigger>
                  <TabsTrigger value="claimed" data-testid="tab-claimed">
                    Claimed ({claimedBusinesses.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="unclaimed" className="mt-6">
                  {unclaimedBusinesses.length === 0 ? (
                    <div className="text-center py-8">
                      <MapPin className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">No unclaimed businesses</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        All businesses in your current filter are already claimed.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4" data-testid="unclaimed-businesses-list">
                      {unclaimedBusinesses.map((business: Business) => (
                        <BusinessCard
                          key={business.id}
                          business={business}
                          onCreatePackage={handleCreatePackage}
                          onSendEmail={handleSendEmail}
                        />
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="claimed" className="mt-6">
                  {claimedBusinesses.length === 0 ? (
                    <div className="text-center py-8">
                      <Building className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">No claimed businesses</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        No claimed businesses found with your current filters.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4" data-testid="claimed-businesses-list">
                      {claimedBusinesses.map((business: Business) => (
                        <BusinessCard
                          key={business.id}
                          business={business}
                          showActions={false}
                        />
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </main>

      <PackageModal
        open={packageModalOpen}
        onOpenChange={setPackageModalOpen}
        business={selectedBusiness}
      />
    </>
  );
}

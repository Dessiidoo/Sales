import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { useToast } from "@/hooks/use-toast";
import { insertBusinessSchema, type InsertBusiness } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const businessTypes = [
  "Restaurant", "Hair Salon", "Landscaping", "Cleaning Service", "Auto Repair",
  "Dental Office", "Law Firm", "Real Estate", "Fitness Center", "Pet Services",
  "HVAC", "Plumbing", "Electrical", "Roofing", "Home Improvement"
];

const manualEntrySchema = insertBusinessSchema.omit({
  googlePlaceId: true,
  isContacted: true,
  responseStatus: true,
  notes: true,
  source: true
});

export default function ManualEntry() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertBusiness>({
    resolver: zodResolver(manualEntrySchema),
    defaultValues: {
      name: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      phone: "",
      email: "",
      website: "",
      businessType: "",
      isClaimed: false,
    },
  });

  const createBusinessMutation = useMutation({
    mutationFn: async (data: InsertBusiness) => {
      const businessData = {
        ...data,
        googlePlaceId: `manual-${Date.now()}-${Math.random()}`,
        isContacted: false,
        responseStatus: null,
        notes: null,
        source: 'manual_entry'
      };
      return apiRequest("/api/businesses", "POST", businessData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/businesses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success!",
        description: "Business added successfully. You can now generate packages and send emails.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add business",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBusiness) => {
    createBusinessMutation.mutate(data);
  };

  return (
    <div className="container mx-auto p-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Manual Business Entry</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Add businesses manually while API integrations are being configured. Perfect for testing the complete JeoSync workflow.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Add New Business</CardTitle>
            <CardDescription>
              Enter business details to test package generation and email outreach
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g. Joe's Pizza Palace" 
                            {...field}
                            data-testid="input-business-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="businessType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Type *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-business-type">
                              <SelectValue placeholder="Select business type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {businessTypes.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="123 Main Street" 
                          {...field}
                          data-testid="input-address"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="New Bern" 
                            {...field}
                            data-testid="input-city"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="NC" 
                            {...field}
                            data-testid="input-state"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="zipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ZIP Code</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="28560" 
                            {...field} 
                            value={field.value || ""}
                            data-testid="input-zip"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="(252) 555-0123" 
                            {...field} 
                            value={field.value || ""}
                            data-testid="input-phone"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="owner@business.com" 
                            type="email" 
                            {...field} 
                            value={field.value || ""}
                            data-testid="input-email"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="website"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Website</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://www.business.com" 
                          type="url" 
                          {...field} 
                          value={field.value || ""}
                          data-testid="input-website"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isClaimed"
                    {...form.register("isClaimed")}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    data-testid="checkbox-claimed"
                  />
                  <label htmlFor="isClaimed" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Business already has claimed Google listing
                  </label>
                </div>

                <div className="flex justify-end">
                  <Button 
                    type="submit" 
                    disabled={createBusinessMutation.isPending}
                    data-testid="button-add-business"
                  >
                    {createBusinessMutation.isPending ? "Adding..." : "Add Business"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <h3 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Next Steps:</h3>
          <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
            <li>1. Add a few sample businesses using this form</li>
            <li>2. Go to "Found Businesses" to see your entries</li>
            <li>3. Generate service packages for each business</li>
            <li>4. Test email templates and payment integration</li>
            <li>5. Complete end-to-end JeoSync workflow testing</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
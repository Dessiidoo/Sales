import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, Plus, Edit, Trash2, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface PackageComponent {
  name: string;
  price: number;
  description?: string;
}

interface PackageTemplate {
  id: string;
  name: string;
  description: string;
  price: number;
  businessType: string | null;
  components: PackageComponent[];
  isTemplate: boolean;
  createdAt: string;
}

export default function PackageBuilder() {
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<PackageTemplate | undefined>();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    businessType: "",
    selectedComponents: [] as string[],
  });
  const { toast } = useToast();

  // Fetch package templates
  const { data: templates = [], isLoading: templatesLoading } = useQuery({
    queryKey: ["/api/packages/templates"],
  });

  // Fetch business types
  const { data: businessTypes = [] } = useQuery({
    queryKey: ["/api/business-types"],
  });

  // Fetch components for selected business type
  const { data: availableComponents = [] } = useQuery({
    queryKey: ["/api/packages/components", formData.businessType || "general"],
    enabled: !!formData.businessType || createModalOpen,
  });

  // Calculate price mutation
  const calculatePriceMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/packages/calculate-price", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          components: formData.selectedComponents,
          businessType: formData.businessType || "general",
        }),
      });
      if (!response.ok) throw new Error("Failed to calculate price");
      return response.json();
    },
  });

  // Create package mutation
  const createPackageMutation = useMutation({
    mutationFn: async () => {
      const selectedComponentsData = availableComponents.filter((comp: PackageComponent) =>
        formData.selectedComponents.includes(comp.name)
      );

      const response = await fetch("/api/packages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          businessType: formData.businessType || null,
          components: selectedComponentsData,
          isTemplate: true,
        }),
      });
      if (!response.ok) throw new Error("Failed to create package");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Package Created",
        description: "Your package template has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/packages/templates"] });
      setCreateModalOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create package template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      businessType: "",
      selectedComponents: [],
    });
  };

  const handleComponentToggle = (componentName: string) => {
    setFormData(prev => ({
      ...prev,
      selectedComponents: prev.selectedComponents.includes(componentName)
        ? prev.selectedComponents.filter(name => name !== componentName)
        : [...prev.selectedComponents, componentName]
    }));
  };

  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(2)}`;
  };

  const calculateTotalPrice = () => {
    return availableComponents
      .filter((comp: PackageComponent) => formData.selectedComponents.includes(comp.name))
      .reduce((total: number, comp: PackageComponent) => total + comp.price, 0);
  };

  const handlePreview = (template: PackageTemplate) => {
    setSelectedTemplate(template);
    setPreviewModalOpen(true);
  };

  return (
    <>
      <Header
        title="Package Builder"
        subtitle="Create and manage service packages for different business types"
        showSearchButton={false}
      />

      <main className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Create New Package Panel */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center" data-testid="create-package-title">
                  <Plus className="mr-2 h-5 w-5" />
                  Quick Create
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Dialog open={createModalOpen} onOpenChange={setCreateModalOpen}>
                  <DialogTrigger asChild>
                    <Button className="w-full" data-testid="button-create-new-package">
                      <Plus className="mr-2 h-4 w-4" />
                      New Package Template
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="create-package-modal">
                    <DialogHeader>
                      <DialogTitle>Create New Package Template</DialogTitle>
                    </DialogHeader>
                    
                    <div className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Package Name *
                          </label>
                          <Input
                            value={formData.name}
                            onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                            placeholder="e.g., Complete SEO Package"
                            data-testid="input-package-name"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Business Type
                          </label>
                          <Select 
                            value={formData.businessType} 
                            onValueChange={(value) => setFormData(prev => ({...prev, businessType: value}))}
                          >
                            <SelectTrigger data-testid="select-business-type">
                              <SelectValue placeholder="All Business Types" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Business Types</SelectItem>
                              {businessTypes.map((type: string) => (
                                <SelectItem key={type} value={type}>
                                  {type}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Description *
                        </label>
                        <Textarea
                          value={formData.description}
                          onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))}
                          placeholder="Describe what this package includes and its benefits..."
                          rows={3}
                          data-testid="textarea-package-description"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Package Components
                        </label>
                        <div className="space-y-3 max-h-60 overflow-y-auto border border-gray-200 rounded-lg p-4">
                          {availableComponents.map((component: PackageComponent) => (
                            <label key={component.name} className="flex items-start space-x-3">
                              <Checkbox
                                checked={formData.selectedComponents.includes(component.name)}
                                onCheckedChange={() => handleComponentToggle(component.name)}
                                data-testid={`checkbox-${component.name.toLowerCase().replace(/\s+/g, '-')}`}
                              />
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-sm text-gray-700">{component.name}</span>
                                  <Badge variant="outline">
                                    {formatPrice(component.price)}
                                  </Badge>
                                </div>
                                {component.description && (
                                  <p className="text-xs text-gray-500 mt-1">{component.description}</p>
                                )}
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-700">Total Package Price:</span>
                          <span className="text-lg font-bold text-primary" data-testid="calculated-price">
                            {formatPrice(calculateTotalPrice())}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end space-x-3 pt-4">
                      <Button
                        variant="outline"
                        onClick={() => setCreateModalOpen(false)}
                        data-testid="button-cancel-create"
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={() => createPackageMutation.mutate()}
                        disabled={!formData.name || !formData.description || formData.selectedComponents.length === 0 || createPackageMutation.isPending}
                        data-testid="button-save-package"
                      >
                        {createPackageMutation.isPending ? "Creating..." : "Create Package"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <div className="mt-6 space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Quick Stats</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Total Templates</span>
                        <span className="font-medium" data-testid="stat-total-templates">
                          {templates.length}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Business Types</span>
                        <span className="font-medium" data-testid="stat-business-types">
                          {businessTypes.length}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Package Templates List */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle data-testid="templates-list-title">Package Templates</CardTitle>
              </CardHeader>
              <CardContent>
                {templatesLoading ? (
                  <div className="text-center py-8">
                    <div className="text-sm text-gray-500">Loading package templates...</div>
                  </div>
                ) : templates.length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No package templates</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Create your first package template to get started.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {templates.map((template: PackageTemplate) => (
                      <div
                        key={template.id}
                        className="border border-gray-200 rounded-lg p-4 hover:border-primary transition-colors"
                        data-testid={`template-card-${template.id}`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900" data-testid="template-name">
                              {template.name}
                            </h4>
                            <p className="text-sm text-gray-600 mt-1" data-testid="template-description">
                              {template.description}
                            </p>
                            {template.businessType && (
                              <Badge variant="outline" className="mt-2" data-testid="template-business-type">
                                {template.businessType}
                              </Badge>
                            )}
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-primary" data-testid="template-price">
                              {formatPrice(template.price)}
                            </div>
                            <div className="text-xs text-gray-500">
                              {Array.isArray(template.components) ? template.components.length : 0} components
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-3">
                          {Array.isArray(template.components) && template.components.slice(0, 3).map((component: PackageComponent, index: number) => (
                            <span
                              key={index}
                              className="inline-flex items-center px-2 py-1 rounded text-xs bg-blue-100 text-blue-800"
                            >
                              {component.name}
                            </span>
                          ))}
                          {Array.isArray(template.components) && template.components.length > 3 && (
                            <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-600">
                              +{template.components.length - 3} more
                            </span>
                          )}
                        </div>

                        <div className="space-y-2">
                          {(template as any).paymentLink && (
                            <div className="flex justify-center">
                              <Button
                                asChild
                                className="w-full bg-blue-600 hover:bg-blue-700"
                                data-testid="button-buy-package"
                              >
                                <a
                                  href={(template as any).paymentLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center justify-center"
                                >
                                  💳 Buy Now - {formatPrice(template.price)}
                                </a>
                              </Button>
                            </div>
                          )}
                          
                          <div className="flex justify-end space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handlePreview(template)}
                              data-testid="button-preview-template"
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              Preview
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              data-testid="button-edit-template"
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-700"
                              data-testid="button-delete-template"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Preview Modal */}
      <Dialog open={previewModalOpen} onOpenChange={setPreviewModalOpen}>
        <DialogContent className="max-w-2xl" data-testid="preview-modal">
          <DialogHeader>
            <DialogTitle>Package Preview</DialogTitle>
          </DialogHeader>
          
          {selectedTemplate && (
            <div className="space-y-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900" data-testid="preview-name">
                  {selectedTemplate.name}
                </h3>
                <p className="text-gray-600 mt-1" data-testid="preview-description">
                  {selectedTemplate.description}
                </p>
                <div className="flex items-center space-x-4 mt-3">
                  <span className="text-2xl font-bold text-primary" data-testid="preview-price">
                    {formatPrice(selectedTemplate.price)}
                  </span>
                  {selectedTemplate.businessType && (
                    <Badge variant="outline" data-testid="preview-business-type">
                      {selectedTemplate.businessType}
                    </Badge>
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-3">Included Components</h4>
                <div className="space-y-2">
                  {Array.isArray(selectedTemplate.components) && selectedTemplate.components.map((component: PackageComponent, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <span className="text-sm font-medium text-gray-900">{component.name}</span>
                        {component.description && (
                          <p className="text-xs text-gray-600 mt-1">{component.description}</p>
                        )}
                      </div>
                      <Badge variant="outline" data-testid={`preview-component-price-${index}`}>
                        {formatPrice(component.price)}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-4">
            {selectedTemplate && (selectedTemplate as any).paymentLink && (
              <Button
                asChild
                className="bg-blue-600 hover:bg-blue-700"
                data-testid="button-buy-preview"
              >
                <a
                  href={(selectedTemplate as any).paymentLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center"
                >
                  💳 Buy Now - {formatPrice(selectedTemplate.price)}
                </a>
              </Button>
            )}
            <Button
              onClick={() => setPreviewModalOpen(false)}
              data-testid="button-close-preview"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

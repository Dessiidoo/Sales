document.getElementById("searchForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = document.getElementById("query").value;

  const res = await fetch(`/search?query=${encodeURIComponent(query)}`);
  const data = await res.json();

  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = ""; // clear old results

  if (data.results && data.results.length > 0) {
    data.results.forEach(r => {
      const addr = r.address && r.address.freeformAddress ? r.address.freeformAddress : "No address";
      const item = document.createElement("div");
      item.className = "result";
      item.innerHTML = `<strong>${addr}</strong>`;
      resultsDiv.appendChild(item);
    });
  } else {
    resultsDiv.innerHTML = "<p>No results found.</p>";
  }
});

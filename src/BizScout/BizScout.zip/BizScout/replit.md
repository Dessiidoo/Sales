# Overview

This is a full-stack business discovery and sales automation platform built with React, TypeScript, Express.js, and PostgreSQL. The application helps users find unclaimed local businesses, generate customized service packages, and automate email outreach campaigns. It features a modern dashboard interface with real-time search capabilities, package building tools, and email template management.

# User Preferences

Preferred communication style: Simple, everyday language.

# Recent Changes

## Professional Lead Generator Creation (August 19, 2025)
- Built premium LeadGen Pro tool for selling to digital marketers
- Advanced lead discovery interface with professional design and animations
- CSV and Excel export functionality with formatted data
- Clickable email and phone links for immediate contact
- Lead scoring system and quality indicators (High/Medium value)
- Advanced filtering and sorting capabilities
- Professional dashboard with real-time statistics
- Manual lead entry system for custom prospects
- Local storage with data persistence across sessions

## Complete Website Rebuild (August 19, 2025)
- Simplified complex platform into three focused HTML pages per user request
- Created professional main page with JeoSync branding and service packages
- Built thank you page for post-purchase customer experience
- Developed private admin page for business lead discovery and management
- Fixed admin page authentication issues with clean working version (my-admin.html)
- Maintained Square payment integration ($99 Basic, $199 Premium packages)
- Added mock business search functionality with local storage for lead tracking
- Streamlined user experience focused on immediate revenue generation
- Eliminated technical complexity in favor of simple, effective solution
- All pages working perfectly and ready for immediate business use

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for development and building
- **UI Components**: Radix UI primitives with shadcn/ui component system for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe forms

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **API Design**: RESTful API with structured JSON responses and error handling
- **Request Processing**: Express middleware for JSON parsing, URL encoding, and request logging
- **Development Tools**: Hot module replacement with Vite integration for seamless development

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL for cloud hosting
- **Schema Management**: Drizzle migrations with schema definitions in TypeScript
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple

## Database Schema Design
- **Businesses Table**: Stores discovered business information including Google Places data, contact details, and claim status
- **Packages Table**: Template-based service packages with JSON components and business type targeting
- **Business Packages Table**: Links businesses to customized packages with pricing and status tracking
- **Email Templates Table**: Customizable email templates with variable substitution support
- **Search Jobs Table**: Tracks business discovery operations with status and metrics

## External Service Integrations
- **Foursquare API**: Business discovery and verification using place search and details endpoints
- **Email Processing**: Template-based email generation with dynamic variable substitution
- **Package Generation**: Rule-based service package creation tailored to business types

## Component Architecture
- **Modular UI Components**: Reusable components following atomic design principles
- **Layout System**: Sidebar navigation with responsive design for mobile and desktop
- **Modal System**: Dialog-based workflows for package creation and email composition
- **Data Visualization**: Statistics cards and progress indicators for dashboard metrics

## Development Workflow
- **Type Safety**: End-to-end TypeScript with shared schema validation between client and server
- **Path Aliases**: Configured import paths for clean module resolution across client, server, and shared code
- **Build Process**: Vite for frontend bundling and esbuild for server compilation
- **Development Mode**: Integrated Vite dev server with Express for unified development experience

# External Dependencies

## Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **drizzle-orm**: Type-safe PostgreSQL ORM with schema management
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **express**: Web application framework for API routes
- **wouter**: Lightweight React routing library

## UI and Styling
- **@radix-ui/react-***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework with design system
- **class-variance-authority**: Utility for managing component variants
- **clsx**: Conditional className utility for dynamic styling

## Development and Build Tools
- **vite**: Frontend build tool and development server
- **esbuild**: Fast JavaScript bundler for server builds
- **tsx**: TypeScript execution environment for development
- **@replit/vite-plugin-runtime-error-modal**: Development error handling

## Validation and Forms
- **zod**: Runtime type validation and schema definition
- **react-hook-form**: Performant form library with validation
- **@hookform/resolvers**: Validation resolver for React Hook Form

## Date and Utility Libraries
- **date-fns**: Modern JavaScript date utility library
- **nanoid**: URL-safe unique string ID generator
- **cmdk**: Command palette component for search interfaces
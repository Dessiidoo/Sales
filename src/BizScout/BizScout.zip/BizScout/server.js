// server.js
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();

// --- config ---
const ADMIN_KEY = process.env.ADMIN_KEY;          // set in Secrets
const PORT = process.env.PORT || 3000;

// --- middleware ---
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// serve your static site (public folder)
app.use(express.static(path.join(__dirname, 'public')));

// helpers
function requireAdmin(req, res, next) {
  const key = req.cookies.admin;
  if (!ADMIN_KEY) {
    return res.status(500).send('Server not configured (missing ADMIN_KEY).');
  }
  if (key === ADMIN_KEY) return next();
  return res.status(401).send('Unauthorized');
}

// health checks
app.get('/healthz', (_req, res) => res.json({ ok: true }));
app.get('/readyz', (_req, res) => res.json({ ok: true }));

// --- login UI ---
app.get('/login', (_req, res) => {
  res.send(`<!doctype html>
<html lang="en">
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>JeoSync Admin Login</title>
<style>
  :root { color-scheme: dark; }
  body{font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
       background:#0b1220;color:#e6efff;display:grid;place-items:center;
       min-height:100vh;margin:0;padding:24px}
  .card{background:#111a2e;border:1px solid #203456;border-radius:14px;
        padding:24px;max-width:380px;width:100%;box-shadow:0 10px 30px rgba(0,0,0,.25)}
  h1{font-size:22px;margin:0 0 12px}
  p{opacity:.85;margin:0 0 18px}
  label{display:block;margin:12px 0 6px}
  input{width:100%;padding:12px 14px;background:#0f1729;border:1px solid #203456;
        border-radius:10px;color:#e6efff;outline:none}
  button{margin-top:14px;width:100%;padding:12px 16px;border-radius:10px;
         background:#3b82f6;border:0;color:white;font-weight:600;cursor:pointer}
  button:hover{filter:brightness(1.05)}
  .hint{font-size:12px;opacity:.7;margin-top:10px}
</style>
<div class="card">
  <h1>JeoSync Admin</h1>
  <p>Enter your admin key to access the private tools.</p>
  <form method="post" action="/login">
    <label for="key">Admin key</label>
    <input id="key" name="key" type="password" autocomplete="current-password" required />
    <button type="submit">Sign in</button>
  </form>
  <div class="hint">Cookie will be set for this browser for 12 hours.</div>
</div>
</html>`);
});

// --- login handler (sets cookie) ---
app.post('/login', (req, res) => {
  const { key } = req.body || {};
  if (!ADMIN_KEY) return res.status(500).send('Server not configured (missing ADMIN_KEY).');
  if (key === ADMIN_KEY) {
    // set cookie for 12 hours
    res.cookie('admin', ADMIN_KEY, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 12 * 60 * 60 * 1000
    });
    return res.redirect('/search'); // go straight to search
  }
  return res.status(401).send('Invalid key');
});

// logout clears cookie
app.post('/logout', (req, res) => {
  res.clearCookie('admin');
  res.redirect('/login');
});

// --- protected route(s) ---
app.get('/search', requireAdmin, (_req, res) => {
  // TODO: replace with your real search UI/JSON
  res.send(`<h1>Search Admin</h1><p>You're authenticated. Build your UI here.</p>
  <form method="post" action="/logout"><button>Log out</button></form>`);
});

// fallthrough: let static index serve homepage
app.get('/', (req, res, next) => {
  // if you want a plain text ping:
  // return res.send('✅ JeoSync is running!');
  // otherwise send your site index
  res.sendFile(path.join(__dirname, 'public', 'index.html'), err => {
    if (err) next(); // if no public index.html, just end
  });
});

// start server
app.listen(PORT, () => {
  console.log(`JeoSync listening on http://localhost:${PORT}`);
});

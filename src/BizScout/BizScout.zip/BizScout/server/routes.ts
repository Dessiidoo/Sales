import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { businessDiscoveryService } from "./services/businessDiscovery";
import { packageGeneratorService } from "./services/packageGenerator";
import { emailGeneratorService } from "./services/emailGenerator";
import { insertBusinessSchema, insertSearchJobSchema, insertBusinessPackageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Dashboard stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Business discovery
  app.post("/api/search/businesses", async (req, res) => {
    try {
      const searchJobData = insertSearchJobSchema.parse(req.body);
      
      // Create search job
      const job = await storage.createSearchJob(searchJobData);
      
      // Start search in background
      businessDiscoveryService.searchBusinesses(
        searchJobData.businessType,
        searchJobData.location,
        searchJobData.radius,
        storage
      ).then(async (businesses) => {
        await storage.updateSearchJob(job.id, {
          status: 'completed',
          businessesFound: businesses.length,
          unclaimedFound: businesses.filter(b => !b.isClaimed).length,
          completedAt: new Date(),
        });
      }).catch(async (error) => {
        await storage.updateSearchJob(job.id, {
          status: 'failed',
          errorMessage: error.message,
          completedAt: new Date(),
        });
      });

      res.json(job);
    } catch (error) {
      res.status(400).json({ message: "Invalid search parameters" });
    }
  });

  // Get search jobs
  app.get("/api/search/jobs", async (req, res) => {
    try {
      const jobs = await storage.getSearchJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch search jobs" });
    }
  });

  // Get search job by ID
  app.get("/api/search/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getSearchJob(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Search job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch search job" });
    }
  });

  // Get businesses
  app.get("/api/businesses", async (req, res) => {
    try {
      const { type, unclaimed } = req.query;
      let businesses;
      
      if (unclaimed === 'true') {
        businesses = await storage.getUnclaimedBusinesses();
      } else if (type) {
        businesses = await storage.getBusinessesByType(type as string);
      } else {
        businesses = await storage.getBusinesses();
      }
      
      res.json(businesses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch businesses" });
    }
  });

  // Get business by ID
  app.get("/api/businesses/:id", async (req, res) => {
    try {
      const business = await storage.getBusiness(req.params.id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      res.json(business);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch business" });
    }
  });

  // Create business
  app.post("/api/businesses", async (req, res) => {
    try {
      const businessData = insertBusinessSchema.parse(req.body);
      const business = await storage.createBusiness(businessData);
      res.status(201).json(business);
    } catch (error: any) {
      console.error("Failed to create business:", error);
      res.status(400).json({ message: "Failed to create business", error: error?.message || "Unknown error" });
    }
  });

  // Update business
  app.patch("/api/businesses/:id", async (req, res) => {
    try {
      const updates = req.body;
      const business = await storage.updateBusiness(req.params.id, updates);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      res.json(business);
    } catch (error) {
      res.status(500).json({ message: "Failed to update business" });
    }
  });

  // Get business types
  app.get("/api/business-types", async (req, res) => {
    try {
      const types = businessDiscoveryService.getBusinessTypes();
      res.json(types);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch business types" });
    }
  });

  // Package templates
  app.get("/api/packages/templates", async (req, res) => {
    try {
      const templates = await storage.getPackageTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch package templates" });
    }
  });

  // Get packages for business type
  app.get("/api/packages/business-type/:type", async (req, res) => {
    try {
      const packages = await storage.getPackagesByBusinessType(req.params.type);
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch packages" });
    }
  });

  // Generate packages for business
  app.post("/api/businesses/:id/generate-packages", async (req, res) => {
    try {
      const business = await storage.getBusiness(req.params.id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      const packages = packageGeneratorService.generatePackageForBusiness(business);
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate packages" });
    }
  });

  // Get available components for business type
  app.get("/api/packages/components/:businessType", async (req, res) => {
    try {
      const components = packageGeneratorService.getAvailableComponents(req.params.businessType);
      res.json(components);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch components" });
    }
  });

  // Create custom package
  app.post("/api/packages/custom", async (req, res) => {
    try {
      const { businessId, components, customMessage } = req.body;
      
      if (!businessId || !components || !Array.isArray(components)) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const package_ = await packageGeneratorService.createCustomPackage(
        businessId,
        components,
        customMessage
      );
      
      res.json(package_);
    } catch (error) {
      res.status(500).json({ message: "Failed to create custom package" });
    }
  });

  // Calculate package price
  app.post("/api/packages/calculate-price", async (req, res) => {
    try {
      const { components, businessType } = req.body;
      
      if (!components || !businessType) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const price = packageGeneratorService.calculatePackagePrice(components, businessType);
      res.json({ price });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate price" });
    }
  });

  // Business packages
  app.post("/api/business-packages", async (req, res) => {
    try {
      const businessPackageData = insertBusinessPackageSchema.parse(req.body);
      const businessPackage = await storage.createBusinessPackage(businessPackageData);
      res.json(businessPackage);
    } catch (error) {
      res.status(400).json({ message: "Invalid business package data" });
    }
  });

  // Get business packages for a business
  app.get("/api/businesses/:id/packages", async (req, res) => {
    try {
      const packages = await storage.getBusinessPackagesByBusiness(req.params.id);
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch business packages" });
    }
  });

  // Email templates
  app.get("/api/email-templates", async (req, res) => {
    try {
      const { businessType } = req.query;
      let templates;
      
      if (businessType) {
        templates = await storage.getEmailTemplatesByBusinessType(businessType as string);
      } else {
        templates = await storage.getEmailTemplates();
      }
      
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email templates" });
    }
  });

  // Generate email for business
  app.post("/api/businesses/:id/generate-email", async (req, res) => {
    try {
      const { packageId, templateId, customMessage } = req.body;
      
      const business = await storage.getBusiness(req.params.id);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      let package_ = null;
      if (packageId) {
        package_ = await storage.getPackage(packageId);
      }

      const email = await emailGeneratorService.generateEmailForBusiness(
        business,
        package_ || undefined,
        templateId,
        customMessage
      );

      res.json(email);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate email" });
    }
  });

  // Generate package email
  app.post("/api/generate-package-email", async (req, res) => {
    try {
      const { businessId, packageId, customMessage } = req.body;
      
      const business = await storage.getBusiness(businessId);
      const package_ = await storage.getPackage(packageId);
      
      if (!business || !package_) {
        return res.status(404).json({ message: "Business or package not found" });
      }

      const email = await emailGeneratorService.generatePackageEmail(
        business,
        package_,
        customMessage
      );

      res.json(email);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate package email" });
    }
  });

  // Get email variables
  app.get("/api/email-variables", async (req, res) => {
    try {
      const variables = emailGeneratorService.getEmailVariables();
      res.json(variables);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email variables" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { storage, type IStorage } from "../storage";
import { type InsertBusiness } from "@shared/schema";

// v3 API format  
interface FoursquarePlace {
  fsq_id: string;
  name: string;
  location: {
    address?: string;
    formatted_address?: string;
    locality?: string;
    region?: string;
    postcode?: string;
    country?: string;
  };
  geocodes: {
    main: {
      latitude: number;
      longitude: number;
    };
  };
  categories: Array<{
    id: number;
    name: string;
  }>;
  tel?: string;
  website?: string;
  verified?: boolean;
  stats?: {
    total_photos?: number;
    total_ratings?: number;
    total_tips?: number;
  };
}

// v2 API format (for OAuth)
interface FoursquareVenue {
  id: string;
  name: string;
  location: {
    address?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
    formattedAddress?: string[];
    lat?: number;
    lng?: number;
  };
  categories: Array<{
    id: string;
    name: string;
    primary?: boolean;
  }>;
  contact?: {
    phone?: string;
    formattedPhone?: string;
  };
  url?: string;
  verified?: boolean;
  stats?: {
    checkinsCount?: number;
    usersCount?: number;
    tipCount?: number;
  };
}

interface FoursquareV2Response {
  meta: {
    code: number;
    requestId: string;
    errorType?: string;
    errorDetail?: string;
  };
  response: {
    venues: FoursquareVenue[];
  };
}

interface FoursquareV3Response {
  results: FoursquarePlace[];
  context?: {
    geo_bounds?: {
      circle?: {
        center: {
          latitude: number;
          longitude: number;
        };
        radius: number;
      };
    };
  };
}

// Azure Maps API interfaces
interface AzureMapsResult {
  id: string;
  name: string;
  address: {
    freeformAddress?: string;
    municipality?: string;
    adminDistrict?: string;
    postalCode?: string;
    country?: string;
  };
  position: {
    lat: number;
    lon: number;
  };
  poi?: {
    name: string;
    phone?: string;
    categorySet?: Array<{
      id: number;
      name: string;
    }>;
    url?: string;
    categories?: string[];
  };
  type: string;
  score: number;
}

interface AzureMapsResponse {
  summary: {
    query: string;
    queryType: string;
    queryTime: number;
    numResults: number;
    offset: number;
    totalResults: number;
    fuzzyLevel: number;
  };
  results: AzureMapsResult[];
}

export class BusinessDiscoveryService {
  private foursquareApiKey: string;
  private foursquareClientId: string;
  private foursquareClientSecret: string;
  private azureMapsApiKey: string;
  private bingMapsApiKey: string;

  constructor() {
    this.foursquareApiKey = process.env.FOURSQUARE_API_KEY || "";
    this.foursquareClientId = process.env.FOURSQUARE_CLIENT_ID || "";
    this.foursquareClientSecret = process.env.FOURSQUARE_CLIENT_SECRET || "";
    this.azureMapsApiKey = process.env.AZURE_MAPS_API_KEY || "";
    this.bingMapsApiKey = process.env.BING_MAPS_API_KEY || "";
    
    const hasBingMaps = !!this.bingMapsApiKey;
    const hasAzureMaps = !!this.azureMapsApiKey;
    const hasFoursquare = !!this.foursquareApiKey || (!!this.foursquareClientId && !!this.foursquareClientSecret);
    
    if (!hasBingMaps && !hasAzureMaps && !hasFoursquare) {
      console.warn("No API credentials found. Business discovery functionality will be limited.");
    } else if (hasBingMaps) {
      console.log("Bing Maps API configured for business discovery");
    } else if (hasAzureMaps) {
      console.log("Azure Maps API configured for business discovery");
    }
  }

  async searchBusinesses(businessType: string, location: string, radius: number = 25, storage?: IStorage): Promise<InsertBusiness[]> {
    const businesses: InsertBusiness[] = [];

    // Try Azure Maps first (working API key)
    if (this.azureMapsApiKey) {
      try {
        console.log(`Searching Azure Maps for: ${businessType} near ${location}`);
        const results = await this.searchWithAzureMaps(businessType, location, radius);
        if (results && results.length > 0) {
          // Store businesses in database
          if (storage) {
            for (const business of results) {
              await storage.createBusiness(business);
            }
          }
          return results;
        }
      } catch (error) {
        console.warn("Azure Maps search failed, trying Bing Maps:", error);
      }
    }

    // Try Bing Maps second if available
    if (this.bingMapsApiKey) {
      try {
        console.log(`Searching Bing Maps for: ${businessType} near ${location}`);
        const results = await this.searchWithBingMaps(businessType, location, radius);
        if (results && results.length > 0) {
          // Store businesses in database
          if (storage) {
            for (const business of results) {
              await storage.createBusiness(business);
            }
          }
          return results;
        }
      } catch (error) {
        console.warn("Bing Maps search failed, falling back to Foursquare:", error);
      }
    }

    // Fallback to Foursquare if other APIs not available or failed
    return await this.searchWithFoursquare(businessType, location, radius);
  }

  private async searchWithBingMaps(businessType: string, location: string, radius: number = 25): Promise<InsertBusiness[]> {
    const businesses: InsertBusiness[] = [];

    try {
      // Bing Maps Local Search API
      const query = `${businessType}`;
      const url = `https://dev.virtualearth.net/REST/v1/LocalSearch/?query=${encodeURIComponent(query)}&userLocation=${encodeURIComponent(location)}&maxResults=50&key=${this.bingMapsApiKey}`;

      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Bing Maps API Error:', {
          status: response.status,
          statusText: response.statusText,
          body: errorText
        });
        throw new Error(`Bing Maps API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      const resources = data.resourceSets?.[0]?.resources || [];
      console.log(`Found ${resources.length} businesses from Bing Maps`);

      // Parse Bing Maps results
      for (const resource of resources) {
        const address = resource.address || {};
        
        const business: InsertBusiness = {
          name: resource.name || '',
          address: address.formattedAddress || '',
          city: address.locality || '',
          state: address.adminDistrict || '',
          zipCode: address.postalCode || null,
          phone: resource.phoneNumber || null,
          email: null,
          website: resource.website || null,
          businessType: businessType,
          googlePlaceId: resource.entityId || resource.id || '',
          isClaimed: false, // Bing Maps doesn't provide claim status
          isContacted: false,
          responseStatus: null,
          notes: null,
          source: 'bing_maps_search',
        };

        businesses.push(business);
      }

      // Store discovered businesses
      for (const business of businesses) {
        await storage.createBusiness(business);
      }

      return businesses;
    } catch (error) {
      console.error('Error searching Bing Maps:', error);
      throw error;
    }
  }

  private async searchWithAzureMaps(businessType: string, location: string, radius: number = 25): Promise<InsertBusiness[]> {
    const businesses: InsertBusiness[] = [];

    try {
      // First get coordinates for the location
      const geocodeUrl = `https://atlas.microsoft.com/search/address/json?subscription-key=${this.azureMapsApiKey}&api-version=1.0&query=${encodeURIComponent(location)}`;
      
      const geocodeResponse = await fetch(geocodeUrl);
      if (!geocodeResponse.ok) {
        throw new Error(`Azure Maps geocoding failed: ${geocodeResponse.status}`);
      }
      
      const geocodeData = await geocodeResponse.json();
      const firstResult = geocodeData.results?.[0];
      if (!firstResult?.position) {
        throw new Error(`No coordinates found for location: ${location}`);
      }
      
      const lat = firstResult.position.lat;
      const lon = firstResult.position.lon;
      const radiusInMeters = radius * 1609; // Convert miles to meters
      
      // Use POI search with exact coordinates (same as your successful browser test)
      const url = `https://atlas.microsoft.com/search/poi/json?subscription-key=${this.azureMapsApiKey}&api-version=1.0&query=${encodeURIComponent(businessType)}&lat=${lat}&lon=${lon}&radius=${radiusInMeters}&limit=50`;

      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Azure Maps API Error:', {
          status: response.status,
          statusText: response.statusText,
          body: errorText
        });
        throw new Error(`Azure Maps API error: ${response.status} ${response.statusText}`);
      }

      const data: AzureMapsResponse = await response.json();
      console.log(`Found ${data.results?.length || 0} businesses from Azure Maps`);

      // Parse Azure Maps results
      for (const result of data.results || []) {
        const address = result.address || {};
        const poi = result.poi;
        
        const business: InsertBusiness = {
          name: (poi && poi.name) || result.name,
          address: address.freeformAddress || '',
          city: address.municipality || '',
          state: address.adminDistrict || '',
          zipCode: address.postalCode || null,
          phone: (poi && poi.phone) || null,
          email: null,
          website: (poi && poi.url) || null,
          businessType: businessType,
          googlePlaceId: result.id,
          isClaimed: false, // Azure Maps doesn't provide claim status
          isContacted: false,
          responseStatus: null,
          notes: null,
          source: 'azure_maps_search',
        };

        businesses.push(business);
      }

      // Store discovered businesses
      for (const business of businesses) {
        await storage.createBusiness(business);
      }

      return businesses;
    } catch (error) {
      console.error('Error searching Azure Maps:', error);
      throw error;
    }
  }

  private async searchWithFoursquare(businessType: string, location: string, radius: number = 25): Promise<InsertBusiness[]> {
    const businesses: InsertBusiness[] = [];

    // Check for Foursquare credentials
    if (!this.foursquareApiKey && (!this.foursquareClientId || !this.foursquareClientSecret)) {
      throw new Error("No business discovery APIs configured. Please add Azure Maps or Foursquare API credentials.");
    }

    try {
      // Search using Foursquare Places API v3
      const query = `${businessType}`;
      let url = `https://api.foursquare.com/v3/places/search?query=${encodeURIComponent(query)}&near=${encodeURIComponent(location)}&radius=${radius * 1609}&limit=50`;

      console.log(`Searching Foursquare for: ${businessType} near ${location}`);

      let headers: Record<string, string> = { 'Accept': 'application/json' };

      // Try OAuth credentials with v2 API first (has better compatibility)
      if (this.foursquareClientId && this.foursquareClientSecret) {
        // Use v2 API with OAuth which has better support
        url = `https://api.foursquare.com/v2/venues/search?client_id=${this.foursquareClientId}&client_secret=${this.foursquareClientSecret}&v=20230101&near=${encodeURIComponent(location)}&query=${encodeURIComponent(query)}&radius=${radius * 1609}&limit=50`;
        console.log("Using Foursquare v2 API with OAuth credentials");
      } else if (this.foursquareApiKey) {
        // Use Service API Key with v3 API
        headers['Authorization'] = this.foursquareApiKey;
        console.log("Using Foursquare v3 API with Service API Key");
      }

      const response = await fetch(url, { headers });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Foursquare API Error Details:', {
          status: response.status,
          statusText: response.statusText,
          body: errorText,
          usingOAuth: !!(this.foursquareClientId && this.foursquareClientSecret),
          hasApiKey: !!this.foursquareApiKey
        });
        
        if (response.status === 402) {
          throw new Error(`All business discovery APIs have reached their limits. Please upgrade your Foursquare plan or activate your Microsoft API credentials to enable business discovery.`);
        }
        
        if (response.status === 401) {
          throw new Error(`Foursquare API authentication failed. Please verify your API credentials are correct and active in your Foursquare developer account.`);
        }
        
        throw new Error(`Foursquare API error: ${response.status} ${response.statusText}`);
      }

      const responseData = await response.json();
      
      // Handle different API response formats
      let venues: Array<any> = [];
      let apiVersion = 'v3';
      
      if ('meta' in responseData && 'response' in responseData) {
        // v2 API format
        apiVersion = 'v2';
        venues = responseData.response.venues || [];
        console.log(`Found ${venues.length} businesses from Foursquare v2 API`);
      } else if ('results' in responseData) {
        // v3 API format  
        venues = responseData.results || [];
        console.log(`Found ${venues.length} businesses from Foursquare v3 API`);
      }

      for (const venue of venues) {
        let business: InsertBusiness;
        
        if (apiVersion === 'v2') {
          // Parse v2 venue format
          const location = venue.location || {};
          const formattedAddress = location.formattedAddress?.join(', ') || location.address || '';
          
          business = {
            name: venue.name,
            address: formattedAddress,
            city: location.city || '',
            state: location.state || '',
            zipCode: location.postalCode || null,
            phone: venue.contact?.formattedPhone || venue.contact?.phone || null,
            email: null,
            website: venue.url || null,
            businessType: businessType,
            googlePlaceId: venue.id,
            isClaimed: venue.verified || false,
            isContacted: false,
            responseStatus: null,
            notes: null,
            source: 'foursquare_v2_search',
          };
        } else {
          // Parse v3 place format
          const location = venue.location || {};
          const addressParts = this.parseAddress(location.formatted_address || '');
          
          business = {
            name: venue.name,
            address: location.formatted_address || location.address || '',
            city: location.locality || addressParts.city,
            state: location.region || addressParts.state,
            zipCode: location.postcode || addressParts.zipCode,
            phone: venue.tel || null,
            email: null,
            website: venue.website || null,
            businessType: businessType,
            googlePlaceId: venue.fsq_id,
            isClaimed: venue.verified || false,
            isContacted: false,
            responseStatus: null,
            notes: null,
            source: 'foursquare_v3_search',
          };
        }

        businesses.push(business);
      }

      // Store discovered businesses
      for (const business of businesses) {
        await storage.createBusiness(business);
      }

      return businesses;
    } catch (error) {
      console.error('Error searching businesses:', error);
      throw error;
    }
  }

  private async getPlaceDetails(placeId: string): Promise<any> {
    if (!this.foursquareApiKey) return null;

    try {
      const url = `https://api.foursquare.com/v3/places/${placeId}`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': this.foursquareApiKey,
          'Accept': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        return {
          ...data,
          claimed: data.verified || false
        };
      }
      
      return null;
    } catch (error) {
      console.error(`Error getting place details for ${placeId}:`, error);
      return null;
    }
  }

  private parseAddress(formattedAddress: string): { city: string; state: string; zipCode: string | null } {
    // Simple address parsing - in production, you'd want more robust parsing
    const parts = formattedAddress.split(', ');
    const lastPart = parts[parts.length - 1]; // Country
    const secondLastPart = parts[parts.length - 2] || ''; // State ZIP
    const thirdLastPart = parts[parts.length - 3] || ''; // City

    const stateZipMatch = secondLastPart.match(/([A-Z]{2})\s+(\d{5}(-\d{4})?)/);
    
    return {
      city: thirdLastPart,
      state: stateZipMatch ? stateZipMatch[1] : secondLastPart.split(' ')[0] || '',
      zipCode: stateZipMatch ? stateZipMatch[2] : null,
    };
  }

  async checkClaimStatus(placeId: string): Promise<boolean> {
    if (!this.foursquareApiKey) return false;

    try {
      const details = await this.getPlaceDetails(placeId);
      return details?.claimed || false;
    } catch (error) {
      console.error(`Error checking claim status for ${placeId}:`, error);
      return false;
    }
  }

  private generateDemoBusinesses(businessType: string, location: string): InsertBusiness[] {
    const cityName = location.split(',')[0]?.trim() || 'City';
    const demoBusinesses: InsertBusiness[] = [
      {
        name: `${businessType === 'restaurant' ? 'Local Bistro' : 'Main Street ' + businessType.charAt(0).toUpperCase() + businessType.slice(1)}`,
        address: `123 Main St, ${cityName}, NY 10001`,
        city: cityName,
        state: 'NY',
        zipCode: '10001',
        phone: '+1 (555) 123-4567',
        email: null,
        website: null,
        businessType: businessType,
        googlePlaceId: 'demo_001',
        isClaimed: false,
        isContacted: false,
        responseStatus: null,
        notes: null,
        source: 'demo_data',
      },
      {
        name: `${businessType === 'restaurant' ? 'Corner Cafe' : 'Downtown ' + businessType.charAt(0).toUpperCase() + businessType.slice(1)}`,
        address: `456 Oak Ave, ${cityName}, NY 10002`,
        city: cityName,
        state: 'NY', 
        zipCode: '10002',
        phone: '+1 (555) 234-5678',
        email: null,
        website: null,
        businessType: businessType,
        googlePlaceId: 'demo_002',
        isClaimed: false,
        isContacted: false,
        responseStatus: null,
        notes: null,
        source: 'demo_data',
      },
      {
        name: `${businessType === 'restaurant' ? 'Family Diner' : 'West Side ' + businessType.charAt(0).toUpperCase() + businessType.slice(1)}`,
        address: `789 Pine St, ${cityName}, NY 10003`,
        city: cityName,
        state: 'NY',
        zipCode: '10003', 
        phone: '+1 (555) 345-6789',
        email: null,
        website: 'https://example-business.com',
        businessType: businessType,
        googlePlaceId: 'demo_003',
        isClaimed: false,
        isContacted: false,
        responseStatus: null,
        notes: null,
        source: 'demo_data',
      }
    ];

    console.log(`Generated ${demoBusinesses.length} demo businesses for ${businessType} in ${location}`);
    return demoBusinesses;
  }

  getBusinessTypes(): string[] {
    return [
      'Landscaping',
      'Hair Salons', 
      'Cleaning Services',
      'Food Trucks',
      'Auto Repair',
      'Pet Services',
      'Home Improvement',
      'Restaurants',
      'Fitness Centers',
      'Plumbing',
      'Electrical',
      'HVAC',
      'Roofing',
      'Pest Control',
      'Real Estate',
    ];
  }
}

export const businessDiscoveryService = new BusinessDiscoveryService();

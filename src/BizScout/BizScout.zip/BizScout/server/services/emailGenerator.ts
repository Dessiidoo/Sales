import { storage } from "../storage";
import { type Business, type Package, type EmailTemplate } from "@shared/schema";

interface EmailVariables {
  businessName: string;
  ownerName?: string;
  businessType: string;
  address: string;
  packageName?: string;
  packagePrice?: string;
  packageComponents?: string[];
  senderName: string;
  senderCompany: string;
  senderPhone?: string;
  senderEmail?: string;
  customMessage?: string;
}

export class EmailGeneratorService {
  private defaultSenderInfo = {
    senderName: process.env.DEFAULT_SENDER_NAME || "Local Business Expert",
    senderCompany: process.env.DEFAULT_SENDER_COMPANY || "LocalBiz Finder",
    senderPhone: process.env.DEFAULT_SENDER_PHONE || "",
    senderEmail: process.env.DEFAULT_SENDER_EMAIL || "",
  };

  async generateEmailForBusiness(
    business: Business,
    packageInfo?: Package,
    templateId?: string,
    customMessage?: string
  ): Promise<{ subject: string; content: string }> {
    
    // Get email template
    let template: EmailTemplate | undefined;
    
    if (templateId) {
      template = await storage.getEmailTemplate(templateId);
    } else {
      template = await storage.getDefaultEmailTemplate(business.businessType);
    }

    if (!template) {
      // Fallback to general template
      const templates = await storage.getEmailTemplates();
      template = templates.find(t => t.isDefault && !t.businessType);
    }

    if (!template) {
      throw new Error("No email template found");
    }

    // Prepare variables for template substitution
    const variables: EmailVariables = {
      businessName: business.name,
      businessType: business.businessType,
      address: business.address,
      ...this.defaultSenderInfo,
      customMessage: customMessage || "",
    };

    if (packageInfo) {
      variables.packageName = packageInfo.name;
      variables.packagePrice = this.formatPrice(packageInfo.price);
      variables.packageComponents = Array.isArray(packageInfo.components) 
        ? packageInfo.components.map((c: any) => c.name)
        : [];
    }

    // Substitute variables in template
    const subject = this.substituteVariables(template.subject, variables);
    const content = this.substituteVariables(template.content, variables);

    return { subject, content };
  }

  async generatePackageEmail(
    business: Business,
    packageInfo: Package,
    customMessage?: string
  ): Promise<{ subject: string; content: string }> {
    
    const variables: EmailVariables = {
      businessName: business.name,
      businessType: business.businessType,
      address: business.address,
      packageName: packageInfo.name,
      packagePrice: this.formatPrice(packageInfo.price),
      packageComponents: Array.isArray(packageInfo.components) 
        ? packageInfo.components.map((c: any) => c.name)
        : [],
      customMessage: customMessage || "",
      ...this.defaultSenderInfo,
    };

    // Custom package email template
    const subject = `Boost Your ${business.businessType} Business - ${packageInfo.name}`;
    
    const content = `Hi there,

I found your business "${business.name}" online and noticed some opportunities to improve your digital presence and attract more local customers.

I've put together a customized package specifically for your ${business.businessType} business:

📦 ${packageInfo.name}
💰 Total Value: ${this.formatPrice(packageInfo.price)}

What's included:
${Array.isArray(packageInfo.components) 
  ? packageInfo.components.map((c: any) => `✓ ${c.name}${c.description ? ` - ${c.description}` : ''}`).join('\n')
  : '✓ Complete business optimization package'
}

${customMessage ? `\n${customMessage}\n` : ''}

This package is designed to help businesses like yours:
• Appear higher in local Google searches
• Attract more customers in your area
• Build trust with professional online presence
• Get more positive reviews
• Stand out from competitors

I'd love to discuss how this can help grow your business. Would you be available for a quick 15-minute call this week?

Best regards,
${variables.senderName}
${variables.senderCompany}
${variables.senderPhone ? `Phone: ${variables.senderPhone}` : ''}
${variables.senderEmail ? `Email: ${variables.senderEmail}` : ''}

P.S. I'm offering this analysis completely free with no obligation. My goal is to help local businesses like yours succeed online.`;

    return { subject, content };
  }

  private substituteVariables(template: string, variables: EmailVariables): string {
    let result = template;
    
    // Replace all variables in the format {variableName}
    Object.entries(variables).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        const regex = new RegExp(`{${key}}`, 'g');
        result = result.replace(regex, String(value));
      }
    });

    // Handle special formatting for package components
    if (variables.packageComponents && variables.packageComponents.length > 0) {
      const componentsList = variables.packageComponents
        .map(component => `• ${component}`)
        .join('\n');
      result = result.replace('{packageComponentsList}', componentsList);
    }

    return result;
  }

  private formatPrice(priceInCents: number): string {
    return `$${(priceInCents / 100).toFixed(2)}`;
  }

  async createEmailTemplate(
    name: string,
    subject: string,
    content: string,
    businessType?: string,
    isDefault: boolean = false
  ): Promise<EmailTemplate> {
    
    const template = await storage.createEmailTemplate({
      name,
      subject,
      content,
      businessType: businessType || null,
      isDefault,
    });

    return template;
  }

  getEmailVariables(): string[] {
    return [
      'businessName',
      'ownerName',
      'businessType',
      'address',
      'packageName',
      'packagePrice',
      'packageComponentsList',
      'senderName',
      'senderCompany',
      'senderPhone',
      'senderEmail',
      'customMessage',
    ];
  }
}

export const emailGeneratorService = new EmailGeneratorService();

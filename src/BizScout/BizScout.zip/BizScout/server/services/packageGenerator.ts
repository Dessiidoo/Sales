import { storage } from "../storage";
import { type InsertPackage, type Business, type Package } from "@shared/schema";

interface PackageComponent {
  name: string;
  price: number; // in cents
  description?: string;
}

export class PackageGeneratorService {
  private getComponentsForBusinessType(businessType: string): PackageComponent[] {
    const baseComponents: PackageComponent[] = [
      { name: "Google Business Profile Setup", price: 9900, description: "Complete profile setup and verification" },
      { name: "Professional Photos", price: 14900, description: "High-quality business photos" },
      { name: "Business Hours & Contact Info", price: 4900, description: "Accurate hours and contact details" },
      { name: "Business Description", price: 7900, description: "Compelling business description" },
    ];

    const reviewComponents: PackageComponent[] = [
      { name: "Review Management Setup", price: 19900, description: "Review monitoring and response system" },
      { name: "Review Generation Campaign", price: 14900, description: "Strategies to get more positive reviews" },
    ];

    const seoComponents: PackageComponent[] = [
      { name: "Local SEO Optimization", price: 29900, description: "Optimize for local search results" },
      { name: "Keyword Research", price: 14900, description: "Target the right keywords for your business" },
      { name: "Google Posts Setup", price: 9900, description: "Regular Google Business Profile posts" },
    ];

    const socialComponents: PackageComponent[] = [
      { name: "Social Media Setup", price: 19900, description: "Facebook and Instagram business profiles" },
      { name: "Social Media Content Plan", price: 24900, description: "3-month content strategy" },
    ];

    const websiteComponents: PackageComponent[] = [
      { name: "Basic Website", price: 39900, description: "Simple 5-page business website" },
      { name: "Website SEO", price: 19900, description: "On-page SEO optimization" },
      { name: "Contact Forms & Analytics", price: 9900, description: "Lead capture and tracking setup" },
    ];

    // Business type specific recommendations
    const businessTypeComponents: { [key: string]: PackageComponent[] } = {
      'Landscaping': [
        { name: "Before/After Photo Gallery", price: 12900, description: "Showcase your best work" },
        { name: "Seasonal Service Listings", price: 7900, description: "Highlight seasonal offerings" },
      ],
      'Hair Salons': [
        { name: "Service Menu Setup", price: 9900, description: "Detailed service listings with prices" },
        { name: "Stylist Profiles", price: 12900, description: "Individual stylist bio pages" },
        { name: "Online Booking Integration", price: 24900, description: "Appointment booking system" },
      ],
      'Cleaning Services': [
        { name: "Service Area Map", price: 9900, description: "Visual service area coverage" },
        { name: "Before/After Galleries", price: 12900, description: "Show cleaning transformations" },
      ],
      'Food Trucks': [
        { name: "Menu Photo Gallery", price: 14900, description: "Appetizing food photography" },
        { name: "Location Schedule Setup", price: 9900, description: "Where and when you'll be" },
        { name: "Event Booking System", price: 19900, description: "Private event booking capability" },
      ],
      'Auto Repair': [
        { name: "Service Specializations", price: 9900, description: "Highlight your specialties" },
        { name: "Certification Displays", price: 7900, description: "Show your credentials" },
        { name: "Warranty Information", price: 4900, description: "Service warranty details" },
      ],
    };

    let allComponents = [...baseComponents];
    
    // Add business type specific components
    if (businessTypeComponents[businessType]) {
      allComponents = [...allComponents, ...businessTypeComponents[businessType]];
    }

    // Add other component categories
    allComponents = [
      ...allComponents,
      ...reviewComponents,
      ...seoComponents,
      ...socialComponents,
      ...websiteComponents,
    ];

    return allComponents;
  }

  generatePackageForBusiness(business: Business): InsertPackage[] {
    const components = this.getComponentsForBusinessType(business.businessType);
    const packages: InsertPackage[] = [];

    // Basic Package
    const basicComponents = components.filter(c => 
      c.name.includes('Profile Setup') || 
      c.name.includes('Photos') || 
      c.name.includes('Hours') ||
      c.name.includes('Description')
    );
    
    packages.push({
      name: `${business.businessType} - Basic Package`,
      description: "Essential online presence setup for your business",
      price: basicComponents.reduce((sum, c) => sum + c.price, 0),
      businessType: business.businessType,
      components: basicComponents,
      isTemplate: false,
    });

    // Complete Package
    const completeComponents = [
      ...basicComponents,
      ...components.filter(c => 
        c.name.includes('Review') || 
        c.name.includes('SEO') ||
        c.name.includes('Posts')
      )
    ];

    packages.push({
      name: `${business.businessType} - Complete Package`,
      description: "Comprehensive online marketing solution",
      price: completeComponents.reduce((sum, c) => sum + c.price, 0),
      businessType: business.businessType,
      components: completeComponents,
      isTemplate: false,
    });

    // Premium Package
    const premiumComponents = [
      ...completeComponents,
      ...components.filter(c => 
        c.name.includes('Social') || 
        c.name.includes('Website') ||
        business.businessType === c.name.split(' - ')[0] // Business type specific
      )
    ];

    packages.push({
      name: `${business.businessType} - Premium Package`,
      description: "Complete digital transformation for maximum growth",
      price: premiumComponents.reduce((sum, c) => sum + c.price, 0),
      businessType: business.businessType,
      components: premiumComponents,
      isTemplate: false,
    });

    return packages;
  }

  async createCustomPackage(
    businessId: string,
    selectedComponents: string[],
    customMessage?: string
  ): Promise<Package> {
    const business = await storage.getBusiness(businessId);
    if (!business) {
      throw new Error("Business not found");
    }

    const allComponents = this.getComponentsForBusinessType(business.businessType);
    const packageComponents = allComponents.filter(c => selectedComponents.includes(c.name));
    
    const totalPrice = packageComponents.reduce((sum, c) => sum + c.price, 0);

    const packageData: InsertPackage = {
      name: `Custom Package for ${business.name}`,
      description: customMessage || "Custom package tailored for your business needs",
      price: totalPrice,
      businessType: business.businessType,
      components: packageComponents,
      isTemplate: false,
    };

    return await storage.createPackage(packageData);
  }

  getAvailableComponents(businessType: string): PackageComponent[] {
    return this.getComponentsForBusinessType(businessType);
  }

  calculatePackagePrice(componentNames: string[], businessType: string): number {
    const allComponents = this.getComponentsForBusinessType(businessType);
    const selectedComponents = allComponents.filter(c => componentNames.includes(c.name));
    return selectedComponents.reduce((sum, c) => sum + c.price, 0);
  }
}

export const packageGeneratorService = new PackageGeneratorService();

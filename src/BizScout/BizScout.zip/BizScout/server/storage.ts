import {
  type Business,
  type InsertBusiness,
  type Package,
  type InsertPackage,
  type BusinessPackage,
  type InsertBusinessPackage,
  type EmailTemplate,
  type InsertEmailTemplate,
  type SearchJob,
  type InsertSearchJob,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Business operations
  getBusiness(id: string): Promise<Business | undefined>;
  getBusinesses(): Promise<Business[]>;
  getBusinessesByType(businessType: string): Promise<Business[]>;
  getUnclaimedBusinesses(): Promise<Business[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: string, updates: Partial<Business>): Promise<Business | undefined>;
  
  // Package operations
  getPackage(id: string): Promise<Package | undefined>;
  getPackages(): Promise<Package[]>;
  getPackageTemplates(): Promise<Package[]>;
  getPackagesByBusinessType(businessType: string): Promise<Package[]>;
  createPackage(packageData: InsertPackage): Promise<Package>;
  
  // Business Package operations
  getBusinessPackage(id: string): Promise<BusinessPackage | undefined>;
  getBusinessPackagesByBusiness(businessId: string): Promise<BusinessPackage[]>;
  createBusinessPackage(businessPackage: InsertBusinessPackage): Promise<BusinessPackage>;
  updateBusinessPackage(id: string, updates: Partial<BusinessPackage>): Promise<BusinessPackage | undefined>;
  
  // Email Template operations
  getEmailTemplate(id: string): Promise<EmailTemplate | undefined>;
  getEmailTemplates(): Promise<EmailTemplate[]>;
  getEmailTemplatesByBusinessType(businessType: string): Promise<EmailTemplate[]>;
  getDefaultEmailTemplate(businessType?: string): Promise<EmailTemplate | undefined>;
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  
  // Search Job operations
  getSearchJob(id: string): Promise<SearchJob | undefined>;
  getSearchJobs(): Promise<SearchJob[]>;
  createSearchJob(job: InsertSearchJob): Promise<SearchJob>;
  updateSearchJob(id: string, updates: Partial<SearchJob>): Promise<SearchJob | undefined>;
  
  // Analytics
  getStats(): Promise<{
    businessesFound: number;
    unclaimedListings: number;
    emailsSent: number;
    conversions: number;
  }>;
}

export class MemStorage implements IStorage {
  private businesses: Map<string, Business> = new Map();
  private packages: Map<string, Package> = new Map();
  private businessPackages: Map<string, BusinessPackage> = new Map();
  private emailTemplates: Map<string, EmailTemplate> = new Map();
  private searchJobs: Map<string, SearchJob> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed default package templates
    const defaultPackages: Package[] = [
      {
        id: randomUUID(),
        name: "Basic Profile Setup",
        description: "Simple Google Business Profile setup and basic optimization",
        price: 9900, // $99.00
        businessType: null,
        components: [
          { name: "Profile Setup", price: 4900 },
          { name: "Basic Info & Hours", price: 2500 },
          { name: "Category Selection", price: 2500 }
        ],
        isTemplate: true,
        createdAt: new Date(),
        paymentLink: "https://square.link/u/HbEe9j2D",
      },
      {
        id: randomUUID(),
        name: "Premium Business Build",
        description: "Complete business profile optimization with photos and review setup",
        price: 19900, // $199.00
        businessType: null,
        components: [
          { name: "Everything Basic", price: 9900 },
          { name: "Professional Photos", price: 5000 },
          { name: "Review Management Setup", price: 3000 },
          { name: "Business Description", price: 2000 }
        ],
        isTemplate: true,
        createdAt: new Date(),
        paymentLink: "https://square.link/u/nX6xPM2m",
      }
    ];

    defaultPackages.forEach(pkg => this.packages.set(pkg.id, pkg));

    // Seed default email templates
    const defaultTemplates: EmailTemplate[] = [
      {
        id: randomUUID(),
        name: "General Business Outreach",
        subject: "Improve Your Google Business Listing - Free Analysis",
        content: `Hi {businessName},

I'm reaching out from JeoSync, and I noticed your business on Google but saw that your Google Business Profile isn't fully optimized. This could be costing you potential customers.

JeoSync specializes in helping local businesses like yours improve their online visibility and attract more customers. Here's what we can deliver for you:

BASIC PROFILE SETUP - $99
✓ Complete Google Business Profile setup & optimization
✓ Business hours and contact information updates
✓ Proper category selection and verification
✓ Implementation completed within 3-5 business days
Get started: https://square.link/u/HbEe9j2D

PREMIUM BUSINESS BUILD - $199 
✓ Everything in Basic package
✓ Professional photo optimization and uploads
✓ Review management system setup
✓ Enhanced business description writing
✓ Implementation completed within 5-7 business days
Get started: https://square.link/u/nX6xPM2m

Both packages include full implementation by our team - you don't need to do anything except provide access to your Google Business account. Most of our clients see increased visibility and customer inquiries within 2-3 weeks of completion.

Ready to boost your local presence? Choose a package above or reply with any questions.

Best regards,
JeoSync Team`,
        businessType: null,
        isDefault: true,
        createdAt: new Date(),
      }
    ];

    defaultTemplates.forEach(template => this.emailTemplates.set(template.id, template));
  }

  // Business operations
  async getBusiness(id: string): Promise<Business | undefined> {
    return this.businesses.get(id);
  }

  async getBusinesses(): Promise<Business[]> {
    return Array.from(this.businesses.values()).sort((a, b) => 
      new Date(b.discoveredAt!).getTime() - new Date(a.discoveredAt!).getTime()
    );
  }

  async getBusinessesByType(businessType: string): Promise<Business[]> {
    return Array.from(this.businesses.values())
      .filter(b => b.businessType === businessType)
      .sort((a, b) => new Date(b.discoveredAt!).getTime() - new Date(a.discoveredAt!).getTime());
  }

  async getUnclaimedBusinesses(): Promise<Business[]> {
    return Array.from(this.businesses.values())
      .filter(b => !b.isClaimed)
      .sort((a, b) => new Date(b.discoveredAt!).getTime() - new Date(a.discoveredAt!).getTime());
  }

  async createBusiness(insertBusiness: InsertBusiness): Promise<Business> {
    const id = randomUUID();
    const business: Business = {
      ...insertBusiness,
      id,
      discoveredAt: new Date(),
      lastContactedAt: null,
    };
    this.businesses.set(id, business);
    return business;
  }

  async updateBusiness(id: string, updates: Partial<Business>): Promise<Business | undefined> {
    const business = this.businesses.get(id);
    if (!business) return undefined;

    const updated = { ...business, ...updates };
    this.businesses.set(id, updated);
    return updated;
  }

  // Package operations
  async getPackage(id: string): Promise<Package | undefined> {
    return this.packages.get(id);
  }

  async getPackages(): Promise<Package[]> {
    return Array.from(this.packages.values());
  }

  async getPackageTemplates(): Promise<Package[]> {
    return Array.from(this.packages.values()).filter(p => p.isTemplate);
  }

  async getPackagesByBusinessType(businessType: string): Promise<Package[]> {
    return Array.from(this.packages.values())
      .filter(p => !p.businessType || p.businessType === businessType);
  }

  async createPackage(insertPackage: InsertPackage): Promise<Package> {
    const id = randomUUID();
    const packageData: Package = {
      ...insertPackage,
      id,
      createdAt: new Date(),
    };
    this.packages.set(id, packageData);
    return packageData;
  }

  // Business Package operations
  async getBusinessPackage(id: string): Promise<BusinessPackage | undefined> {
    return this.businessPackages.get(id);
  }

  async getBusinessPackagesByBusiness(businessId: string): Promise<BusinessPackage[]> {
    return Array.from(this.businessPackages.values())
      .filter(bp => bp.businessId === businessId);
  }

  async createBusinessPackage(insertBusinessPackage: InsertBusinessPackage): Promise<BusinessPackage> {
    const id = randomUUID();
    const businessPackage: BusinessPackage = {
      ...insertBusinessPackage,
      id,
      createdAt: new Date(),
      sentAt: null,
    };
    this.businessPackages.set(id, businessPackage);
    return businessPackage;
  }

  async updateBusinessPackage(id: string, updates: Partial<BusinessPackage>): Promise<BusinessPackage | undefined> {
    const businessPackage = this.businessPackages.get(id);
    if (!businessPackage) return undefined;

    const updated = { ...businessPackage, ...updates };
    this.businessPackages.set(id, updated);
    return updated;
  }

  // Email Template operations
  async getEmailTemplate(id: string): Promise<EmailTemplate | undefined> {
    return this.emailTemplates.get(id);
  }

  async getEmailTemplates(): Promise<EmailTemplate[]> {
    return Array.from(this.emailTemplates.values());
  }

  async getEmailTemplatesByBusinessType(businessType: string): Promise<EmailTemplate[]> {
    return Array.from(this.emailTemplates.values())
      .filter(t => !t.businessType || t.businessType === businessType);
  }

  async getDefaultEmailTemplate(businessType?: string): Promise<EmailTemplate | undefined> {
    const templates = Array.from(this.emailTemplates.values())
      .filter(t => t.isDefault && (!t.businessType || t.businessType === businessType));
    return templates[0];
  }

  async createEmailTemplate(insertTemplate: InsertEmailTemplate): Promise<EmailTemplate> {
    const id = randomUUID();
    const template: EmailTemplate = {
      ...insertTemplate,
      id,
      createdAt: new Date(),
    };
    this.emailTemplates.set(id, template);
    return template;
  }

  // Search Job operations
  async getSearchJob(id: string): Promise<SearchJob | undefined> {
    return this.searchJobs.get(id);
  }

  async getSearchJobs(): Promise<SearchJob[]> {
    return Array.from(this.searchJobs.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createSearchJob(insertJob: InsertSearchJob): Promise<SearchJob> {
    const id = randomUUID();
    const job: SearchJob = {
      ...insertJob,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.searchJobs.set(id, job);
    return job;
  }

  async updateSearchJob(id: string, updates: Partial<SearchJob>): Promise<SearchJob | undefined> {
    const job = this.searchJobs.get(id);
    if (!job) return undefined;

    const updated = { ...job, ...updates };
    this.searchJobs.set(id, updated);
    return updated;
  }

  // Analytics
  async getStats(): Promise<{
    businessesFound: number;
    unclaimedListings: number;
    emailsSent: number;
    conversions: number;
  }> {
    const allBusinesses = Array.from(this.businesses.values());
    const allBusinessPackages = Array.from(this.businessPackages.values());

    return {
      businessesFound: allBusinesses.length,
      unclaimedListings: allBusinesses.filter(b => !b.isClaimed).length,
      emailsSent: allBusinessPackages.filter(bp => bp.status !== 'draft').length,
      conversions: allBusinesses.filter(b => b.responseStatus === 'converted').length,
    };
  }
}

export const storage = new MemStorage();

import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const businesses = pgTable("businesses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code"),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  businessType: text("business_type").notNull(),
  googlePlaceId: text("google_place_id"),
  isClaimed: boolean("is_claimed").default(false),
  isContacted: boolean("is_contacted").default(false),
  discoveredAt: timestamp("discovered_at").defaultNow(),
  lastContactedAt: timestamp("last_contacted_at"),
  responseStatus: text("response_status"), // 'no_response', 'interested', 'converted', 'not_interested'
  notes: text("notes"),
  source: text("source").notNull(), // 'google_search', 'directory_scrape', 'manual'
});

export const packages = pgTable("packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // price in cents
  businessType: text("business_type"), // null means applies to all types
  components: jsonb("components").notNull(), // array of component objects
  isTemplate: boolean("is_template").default(false),
  paymentLink: text("payment_link"), // Square payment link
  createdAt: timestamp("created_at").defaultNow(),
});

export const businessPackages = pgTable("business_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessId: varchar("business_id").notNull().references(() => businesses.id),
  packageId: varchar("package_id").notNull().references(() => packages.id),
  customMessage: text("custom_message"),
  totalPrice: integer("total_price").notNull(),
  status: text("status").notNull().default('draft'), // 'draft', 'sent', 'viewed', 'accepted', 'rejected'
  createdAt: timestamp("created_at").defaultNow(),
  sentAt: timestamp("sent_at"),
});

export const emailTemplates = pgTable("email_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  businessType: text("business_type"), // null means applies to all types
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const searchJobs = pgTable("search_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  businessType: text("business_type").notNull(),
  location: text("location").notNull(),
  radius: integer("radius").notNull(), // in miles
  status: text("status").notNull().default('pending'), // 'pending', 'running', 'completed', 'failed'
  businessesFound: integer("businesses_found").default(0),
  unclaimedFound: integer("unclaimed_found").default(0),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertBusinessSchema = createInsertSchema(businesses).omit({
  id: true,
  discoveredAt: true,
});

export const insertPackageSchema = createInsertSchema(packages).omit({
  id: true,
  createdAt: true,
});

export const insertBusinessPackageSchema = createInsertSchema(businessPackages).omit({
  id: true,
  createdAt: true,
  sentAt: true,
});

export const insertEmailTemplateSchema = createInsertSchema(emailTemplates).omit({
  id: true,
  createdAt: true,
});

export const insertSearchJobSchema = createInsertSchema(searchJobs).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type Business = typeof businesses.$inferSelect;
export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type Package = typeof packages.$inferSelect;
export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type BusinessPackage = typeof businessPackages.$inferSelect;
export type InsertBusinessPackage = z.infer<typeof insertBusinessPackageSchema>;
export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;
export type SearchJob = typeof searchJobs.$inferSelect;
export type InsertSearchJob = z.infer<typeof insertSearchJobSchema>;

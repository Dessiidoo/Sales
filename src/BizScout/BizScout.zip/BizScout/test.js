  // test.js
  // Node 20+ has fetch built-in

  const KEY = "GGxuQf0VuHtjwBl6GN0rQzsN57MxSlUF6w7lFYt59kqqUWwoIkeqJQQJ99BHACYeBjF9qsJMAAAgAZMP13ne";

  (async () => {
    try {
      const url = `https://atlas.microsoft.com/search/address/json?api-version=1.0&subscription-key=${KEY}&query=New%20Bern%20NC`;
      const res = await fetch(url);
      const data = await res.json();
      console.log(JSON.stringify(data, null, 2));
    } catch (err) {
      console.error("Error:", err);
    }
  })();